//! Which of the installed Horizon mods are on (`docs/mods.md`), kept in
//! `horizon-mods.txt` beside `options.txt` as `mod.<id>:true` lines. Every
//! mod is off until the player turns it on in Options > Mods. A native mod is
//! built in, so on until turned off (`mod.<id>:false`); the launcher builds
//! only the native mods whose line is `true`.
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::Path,
};

pub const FILE: &str = "horizon-mods.txt";
/// The folder holding `.hmod` files, beside `options.txt`.
pub const DIR: &str = "horizon-mods";
/// Where the launcher installs native mods (`<id>.hnmod`), beside [`DIR`]. They run only in a
/// game the launcher built with them.
pub const NATIVE_DIR: &str = "horizon-native-mods";

#[cfg(target_os = "android")]
pub const ANDROID_BUNDLED: [&str; 20] = [
    "zoom",
    "worldmap",
    "recipes",
    "smartf3",
    "freecam_plus",
    "connected_textures",
    "armorhud",
    "jade",
    "basic_hud",
    "appleskin",
    "visuality_horizon",
    "punchy",
    "freelook",
    "cinematic_interactions",
    "firstpersonmodel",
    "eatinganimation",
    "veinminer",
    "rightharvest",
    "customhud",
    "carryblock",
];
/// Why a native mod installed in [`NATIVE_DIR`] doesn't run in this game.
#[cfg(not(target_os = "android"))]
pub const NOT_BUILT: &str = "Installed, not built into this game: build the game with it in the launcher (Settings > Native mods), then play the instance that build is in.";
#[cfg(target_os = "android")]
pub const NOT_BUILT: &str =
    "Installed, not in this game yet: Compile builds the game with it on Starling's build server.";
/// [`NOT_BUILT`] in the player's language, as the Mods page's tooltip says it.
#[cfg(not(target_os = "android"))]
pub const NOT_BUILT_TIP: &str = "horizon.mods.not_built_tip";
#[cfg(target_os = "android")]
pub const NOT_BUILT_TIP: &str = "starling.mods.native.not_built_tip";

#[derive(Clone, Debug, Default, PartialEq)]
pub struct ModList {
    /// Ids of the mods the player turned on.
    pub enabled: BTreeSet<String>,
    /// Ids of the native mods the player turned off: they rest
    /// (`native_on`) until the launcher's next build leaves them out.
    pub disabled: BTreeSet<String>,
    /// The keys the player chose for mods' keys, mod id → key name → key
    /// (`key.<id>.<name>:key.keyboard.x` lines).
    pub keys: BTreeMap<String, BTreeMap<String, String>>,
    /// What the Mods page shows, filled by the game from the mods it found.
    pub installed: Vec<Installed>,
    /// Android: which game runs and which the next start runs, above the mods.
    pub native_game: Option<NativeGame>,
}

/// Android: the game with native mods as the Mods page says it (game/native_builds.rs): the APK's
/// own or a build with some mods compiled in, then what the player can do about it.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct NativeGame {
    /// Lines of text, each with whether it is a warning (red).
    pub lines: Vec<(String, bool)>,
    pub buttons: Vec<(String, NativeGameAct)>,
}

/// A button of [`NativeGame`].
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NativeGameAct {
    /// The mods turned on, compiled on the build server, or on GitHub's machines through it.
    Compile,
    CompileOnGithub,
    /// The compile under way, shown again.
    ShowCompile,
    Restart,
    /// The next start runs the APK's own game.
    PlayWithout,
    /// Another build server.
    BuildServer,
}

/// One installed mod as the Mods page shows it.
#[derive(Clone, Debug, PartialEq)]
pub struct Installed {
    pub id: String,
    /// `Name 1.0` (the file name when the manifest is unreadable).
    pub title: String,
    /// What it may do, then what it is (the row's tooltip).
    pub description: String,
    /// Why it is not running, when it failed.
    pub problem: Option<String>,
    /// Loaded with `--dev-mod`: always on.
    pub dev: bool,
    /// A native mod (`game/native_hooks.rs`): built into the game, on until
    /// the player turns it off, and its settings page.
    pub native: Option<NativePage>,
}

/// A native mod's settings page: its keys as Key Binds rows, then its
/// buttons. The keys the player chooses are kept in `ModList::keys`.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct NativePage {
    /// Each key's name, label and default key (`key.keyboard.z`).
    pub keys: Vec<[String; 3]>,
    pub buttons: Vec<String>,
    pub slider_insert_after: usize,
    pub sliders: Vec<NativeSlider>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct NativeSlider {
    pub section: String,
    pub label: String,
    pub value: f32,
}

impl ModList {
    pub fn load(dir: &Path) -> Self {
        fs::read_to_string(dir.join(FILE))
            .map(|t| Self::parse(&t))
            .unwrap_or_else(|_| Self::parse(""))
    }
    pub fn parse(text: &str) -> Self {
        let ids = |value: &str| -> BTreeSet<String> {
            text.lines()
                .filter_map(|l| l.split_once(':'))
                .filter(|(_, v)| v.trim() == value)
                .filter_map(|(k, _)| k.trim().strip_prefix("mod."))
                .map(str::to_owned)
                .collect()
        };
        let enabled = ids("true");
        let mut disabled = ids("false");
        #[cfg(target_os = "android")]
        let enabled = {
            let mut enabled = enabled;
            let has_worldmap_preference = text
                .lines()
                .filter_map(|line| line.split_once(':'))
                .any(|(key, _)| key.trim() == "mod.worldmap");
            if enabled.remove("minimap") && !has_worldmap_preference {
                enabled.insert("worldmap".to_owned());
            }
            disabled.remove("minimap");
            enabled.remove("horizon_physics");
            disabled.remove("horizon_physics");
            enabled
        };
        #[cfg(target_os = "android")]
        for id in ANDROID_BUNDLED.iter() {
            if !enabled.contains(*id) {
                disabled.insert((*id).to_owned());
            }
        }
        let mut keys: BTreeMap<String, BTreeMap<String, String>> = BTreeMap::new();
        for (k, v) in text.lines().filter_map(|l| l.split_once(':')) {
            // Mod ids have no dots; a key's name may.
            if let Some((id, name)) = k
                .trim()
                .strip_prefix("key.")
                .and_then(|r| r.split_once('.'))
            {
                let entry = keys.entry(id.to_owned()).or_default();
                entry.insert(name.to_owned(), v.trim().to_owned());
            }
        }
        Self {
            enabled,
            disabled,
            keys,
            ..Default::default()
        }
    }
    pub fn serialize(&self) -> String {
        let on = self.enabled.iter().map(|id| format!("mod.{id}:true\n"));
        let off = self.disabled.iter().map(|id| format!("mod.{id}:false\n"));
        let keys = self.keys.iter().flat_map(|(id, keys)| {
            keys.iter()
                .map(move |(name, key)| format!("key.{id}.{name}:{key}\n"))
        });
        on.chain(off).chain(keys).collect()
    }
    /// Mod `id`'s chosen keys, for `Mods::set_bindings`.
    pub fn keys_of(&self, id: &str) -> Vec<(&str, &str)> {
        self.keys.get(id).map_or_else(Vec::new, |k| {
            k.iter().map(|(n, k)| (n.as_str(), k.as_str())).collect()
        })
    }
    pub fn save(&self, dir: &Path) {
        let path = dir.join(FILE);
        if self.enabled.is_empty()
            && self.disabled.is_empty()
            && self.keys.is_empty()
            && !path.exists()
        {
            return;
        }
        let _ = fs::write(path, self.serialize());
    }
    pub fn is_on(&self, i: usize) -> bool {
        self.installed.get(i).is_some_and(|m| {
            m.dev
                || if m.native.is_some() {
                    !self.disabled.contains(&m.id)
                } else {
                    self.enabled.contains(&m.id)
                }
        })
    }
    /// Turns installed mod `i` on or off (a dev mod stays on). A native mod's
    /// line says `false` when off, so that the launcher's next build leaves
    /// it out, and `true` when on again.
    pub fn toggle(&mut self, i: usize) {
        let Some(m) = self.installed.get(i).filter(|m| !m.dev) else {
            return;
        };
        if m.native.is_some() {
            if self.disabled.remove(&m.id) {
                self.enabled.insert(m.id.clone());
            } else {
                self.enabled.remove(&m.id);
                self.disabled.insert(m.id.clone());
            }
        } else if !self.enabled.remove(&m.id) {
            self.enabled.insert(m.id.clone());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn round_trips_and_ignores_the_rest() {
        let list = ModList::parse("mod.coords_hud:true\nmod.other:false\nzoom:true\n");
        assert_eq!(list.enabled.iter().collect::<Vec<_>>(), ["coords_hud"]);
        assert_eq!(ModList::parse(&list.serialize()), list);
        assert_eq!(ModList::default().serialize(), "");
    }

    #[cfg(target_os = "android")]
    #[test]
    fn removed_native_mods_are_not_bundled_or_defaulted() {
        let list = ModList::parse("");
        for id in [
            "minimap",
            "accurate_block_placement",
            "voicechat",
            "horizon_physics",
        ] {
            assert!(!ANDROID_BUNDLED.contains(&id));
            assert!(!list.disabled.contains(id));
        }
    }

    #[cfg(target_os = "android")]
    #[test]
    fn removed_physics_mod_is_ignored_in_saved_preferences() {
        let list = ModList::parse("mod.horizon_physics:true\nmod.horizon_physics:false\n");
        assert!(!list.enabled.contains("horizon_physics"));
        assert!(!list.disabled.contains("horizon_physics"));
    }

    #[cfg(target_os = "android")]
    #[test]
    fn previous_minimap_opt_in_migrates_to_worldmap_unless_worldmap_was_set() {
        let migrated = ModList::parse("mod.minimap:true\n");
        assert!(migrated.enabled.contains("worldmap"));
        assert!(!migrated.enabled.contains("minimap"));
        assert!(!migrated.disabled.contains("minimap"));

        let explicit_off = ModList::parse("mod.minimap:true\nmod.worldmap:false\n");
        assert!(!explicit_off.enabled.contains("worldmap"));
        assert!(explicit_off.disabled.contains("worldmap"));
    }

    #[test]
    fn keeps_the_keys_players_chose() {
        let text = "mod.zoom:true\nkey.zoom.zoom.in:key.mouse.4\nkey.zoom.out:key.keyboard.x\n";
        let list = ModList::parse(text);
        assert_eq!(
            list.keys_of("zoom"),
            [("out", "key.keyboard.x"), ("zoom.in", "key.mouse.4")]
        );
        assert!(list.keys_of("other").is_empty());
        assert_eq!(ModList::parse(&list.serialize()), list);
    }

    #[test]
    fn toggles_installed_and_native_mods_but_not_dev_ones() {
        let installed = |id: &str, dev| Installed {
            id: id.into(),
            title: id.into(),
            description: String::new(),
            problem: None,
            dev,
            native: None,
        };
        let mut list = ModList {
            installed: vec![installed("a", false), installed("b", true)],
            ..Default::default()
        };
        assert!(!list.is_on(0) && list.is_on(1));
        list.toggle(0);
        list.toggle(1);
        assert!(list.is_on(0) && list.is_on(1));
        assert_eq!(list.serialize(), "mod.a:true\n");
        list.toggle(0);
        assert!(!list.is_on(0));
        list.installed.push(Installed {
            native: Some(NativePage::default()),
            ..installed("c", false)
        });
        // On until turned off; off, the launcher leaves it out.
        assert!(list.is_on(2));
        list.toggle(2);
        assert!(!list.is_on(2));
        assert_eq!(list.serialize(), "mod.c:false\n");
        assert_eq!(ModList::parse(&list.serialize()).disabled, list.disabled);
        list.toggle(2);
        assert!(list.is_on(2));
        assert_eq!(list.serialize(), "mod.c:true\n");
    }
}
