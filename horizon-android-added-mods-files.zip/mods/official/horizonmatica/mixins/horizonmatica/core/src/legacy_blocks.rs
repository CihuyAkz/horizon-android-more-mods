//! 1.12 block ids (`blockId << 4 | data`) to 1.13 states, for MCEdit `.schematic` files.
//! Derived from Horizon's `block_state_data.txt` (generated from vanilla `BlockStateData`).
//! One line per id: `ID<TAB>name<TAB>props` (props `k=v` joined by `;`). Do not edit.

pub(crate) const TABLE: &str = r#"0	minecraft:air	
16	minecraft:stone	
17	minecraft:granite	
18	minecraft:polished_granite	
19	minecraft:diorite	
20	minecraft:polished_diorite	
21	minecraft:andesite	
22	minecraft:polished_andesite	
32	minecraft:grass_block	snowy=false
48	minecraft:dirt	
49	minecraft:coarse_dirt	
50	minecraft:podzol	snowy=false
64	minecraft:cobblestone	
80	minecraft:oak_planks	
81	minecraft:spruce_planks	
82	minecraft:birch_planks	
83	minecraft:jungle_planks	
84	minecraft:acacia_planks	
85	minecraft:dark_oak_planks	
96	minecraft:oak_sapling	stage=0
97	minecraft:spruce_sapling	stage=0
98	minecraft:birch_sapling	stage=0
99	minecraft:jungle_sapling	stage=0
100	minecraft:acacia_sapling	stage=0
101	minecraft:dark_oak_sapling	stage=0
104	minecraft:oak_sapling	stage=1
105	minecraft:spruce_sapling	stage=1
106	minecraft:birch_sapling	stage=1
107	minecraft:jungle_sapling	stage=1
108	minecraft:acacia_sapling	stage=1
109	minecraft:dark_oak_sapling	stage=1
112	minecraft:bedrock	
128	minecraft:water	level=0
129	minecraft:water	level=1
130	minecraft:water	level=2
131	minecraft:water	level=3
132	minecraft:water	level=4
133	minecraft:water	level=5
134	minecraft:water	level=6
135	minecraft:water	level=7
136	minecraft:water	level=8
137	minecraft:water	level=9
138	minecraft:water	level=10
139	minecraft:water	level=11
140	minecraft:water	level=12
141	minecraft:water	level=13
142	minecraft:water	level=14
143	minecraft:water	level=15
144	minecraft:water	level=0
145	minecraft:water	level=1
146	minecraft:water	level=2
147	minecraft:water	level=3
148	minecraft:water	level=4
149	minecraft:water	level=5
150	minecraft:water	level=6
151	minecraft:water	level=7
152	minecraft:water	level=8
153	minecraft:water	level=9
154	minecraft:water	level=10
155	minecraft:water	level=11
156	minecraft:water	level=12
157	minecraft:water	level=13
158	minecraft:water	level=14
159	minecraft:water	level=15
160	minecraft:lava	level=0
161	minecraft:lava	level=1
162	minecraft:lava	level=2
163	minecraft:lava	level=3
164	minecraft:lava	level=4
165	minecraft:lava	level=5
166	minecraft:lava	level=6
167	minecraft:lava	level=7
168	minecraft:lava	level=8
169	minecraft:lava	level=9
170	minecraft:lava	level=10
171	minecraft:lava	level=11
172	minecraft:lava	level=12
173	minecraft:lava	level=13
174	minecraft:lava	level=14
175	minecraft:lava	level=15
176	minecraft:lava	level=0
177	minecraft:lava	level=1
178	minecraft:lava	level=2
179	minecraft:lava	level=3
180	minecraft:lava	level=4
181	minecraft:lava	level=5
182	minecraft:lava	level=6
183	minecraft:lava	level=7
184	minecraft:lava	level=8
185	minecraft:lava	level=9
186	minecraft:lava	level=10
187	minecraft:lava	level=11
188	minecraft:lava	level=12
189	minecraft:lava	level=13
190	minecraft:lava	level=14
191	minecraft:lava	level=15
192	minecraft:sand	
193	minecraft:red_sand	
208	minecraft:gravel	
224	minecraft:gold_ore	
240	minecraft:iron_ore	
256	minecraft:coal_ore	
272	minecraft:oak_log	axis=y
273	minecraft:spruce_log	axis=y
274	minecraft:birch_log	axis=y
275	minecraft:jungle_log	axis=y
276	minecraft:oak_log	axis=x
277	minecraft:spruce_log	axis=x
278	minecraft:birch_log	axis=x
279	minecraft:jungle_log	axis=x
280	minecraft:oak_log	axis=z
281	minecraft:spruce_log	axis=z
282	minecraft:birch_log	axis=z
283	minecraft:jungle_log	axis=z
284	minecraft:oak_bark	
285	minecraft:spruce_bark	
286	minecraft:birch_bark	
287	minecraft:jungle_bark	
288	minecraft:oak_leaves	check_decay=false;decayable=true
289	minecraft:spruce_leaves	check_decay=false;decayable=true
290	minecraft:birch_leaves	check_decay=false;decayable=true
291	minecraft:jungle_leaves	check_decay=false;decayable=true
292	minecraft:oak_leaves	check_decay=false;decayable=false
293	minecraft:spruce_leaves	check_decay=false;decayable=false
294	minecraft:birch_leaves	check_decay=false;decayable=false
295	minecraft:jungle_leaves	check_decay=false;decayable=false
296	minecraft:oak_leaves	check_decay=true;decayable=true
297	minecraft:spruce_leaves	check_decay=true;decayable=true
298	minecraft:birch_leaves	check_decay=true;decayable=true
299	minecraft:jungle_leaves	check_decay=true;decayable=true
300	minecraft:oak_leaves	check_decay=true;decayable=false
301	minecraft:spruce_leaves	check_decay=true;decayable=false
302	minecraft:birch_leaves	check_decay=true;decayable=false
303	minecraft:jungle_leaves	check_decay=true;decayable=false
304	minecraft:sponge	
305	minecraft:wet_sponge	
320	minecraft:glass	
336	minecraft:lapis_ore	
352	minecraft:lapis_block	
368	minecraft:dispenser	facing=down;triggered=false
369	minecraft:dispenser	facing=up;triggered=false
370	minecraft:dispenser	facing=north;triggered=false
371	minecraft:dispenser	facing=south;triggered=false
372	minecraft:dispenser	facing=west;triggered=false
373	minecraft:dispenser	facing=east;triggered=false
376	minecraft:dispenser	facing=down;triggered=true
377	minecraft:dispenser	facing=up;triggered=true
378	minecraft:dispenser	facing=north;triggered=true
379	minecraft:dispenser	facing=south;triggered=true
380	minecraft:dispenser	facing=west;triggered=true
381	minecraft:dispenser	facing=east;triggered=true
384	minecraft:sandstone	
385	minecraft:chiseled_sandstone	
386	minecraft:cut_sandstone	
400	minecraft:note_block	
416	minecraft:red_bed	facing=south;occupied=false;part=foot
417	minecraft:red_bed	facing=west;occupied=false;part=foot
418	minecraft:red_bed	facing=north;occupied=false;part=foot
419	minecraft:red_bed	facing=east;occupied=false;part=foot
424	minecraft:red_bed	facing=south;occupied=false;part=head
425	minecraft:red_bed	facing=west;occupied=false;part=head
426	minecraft:red_bed	facing=north;occupied=false;part=head
427	minecraft:red_bed	facing=east;occupied=false;part=head
428	minecraft:red_bed	facing=south;occupied=true;part=head
429	minecraft:red_bed	facing=west;occupied=true;part=head
430	minecraft:red_bed	facing=north;occupied=true;part=head
431	minecraft:red_bed	facing=east;occupied=true;part=head
432	minecraft:powered_rail	powered=false;shape=north_south
433	minecraft:powered_rail	powered=false;shape=east_west
434	minecraft:powered_rail	powered=false;shape=ascending_east
435	minecraft:powered_rail	powered=false;shape=ascending_west
436	minecraft:powered_rail	powered=false;shape=ascending_north
437	minecraft:powered_rail	powered=false;shape=ascending_south
440	minecraft:powered_rail	powered=true;shape=north_south
441	minecraft:powered_rail	powered=true;shape=east_west
442	minecraft:powered_rail	powered=true;shape=ascending_east
443	minecraft:powered_rail	powered=true;shape=ascending_west
444	minecraft:powered_rail	powered=true;shape=ascending_north
445	minecraft:powered_rail	powered=true;shape=ascending_south
448	minecraft:detector_rail	powered=false;shape=north_south
449	minecraft:detector_rail	powered=false;shape=east_west
450	minecraft:detector_rail	powered=false;shape=ascending_east
451	minecraft:detector_rail	powered=false;shape=ascending_west
452	minecraft:detector_rail	powered=false;shape=ascending_north
453	minecraft:detector_rail	powered=false;shape=ascending_south
456	minecraft:detector_rail	powered=true;shape=north_south
457	minecraft:detector_rail	powered=true;shape=east_west
458	minecraft:detector_rail	powered=true;shape=ascending_east
459	minecraft:detector_rail	powered=true;shape=ascending_west
460	minecraft:detector_rail	powered=true;shape=ascending_north
461	minecraft:detector_rail	powered=true;shape=ascending_south
464	minecraft:sticky_piston	extended=false;facing=down
465	minecraft:sticky_piston	extended=false;facing=up
466	minecraft:sticky_piston	extended=false;facing=north
467	minecraft:sticky_piston	extended=false;facing=south
468	minecraft:sticky_piston	extended=false;facing=west
469	minecraft:sticky_piston	extended=false;facing=east
472	minecraft:sticky_piston	extended=true;facing=down
473	minecraft:sticky_piston	extended=true;facing=up
474	minecraft:sticky_piston	extended=true;facing=north
475	minecraft:sticky_piston	extended=true;facing=south
476	minecraft:sticky_piston	extended=true;facing=west
477	minecraft:sticky_piston	extended=true;facing=east
480	minecraft:cobweb	
496	minecraft:dead_bush	
497	minecraft:grass	
498	minecraft:fern	
512	minecraft:dead_bush	
528	minecraft:piston	extended=false;facing=down
529	minecraft:piston	extended=false;facing=up
530	minecraft:piston	extended=false;facing=north
531	minecraft:piston	extended=false;facing=south
532	minecraft:piston	extended=false;facing=west
533	minecraft:piston	extended=false;facing=east
536	minecraft:piston	extended=true;facing=down
537	minecraft:piston	extended=true;facing=up
538	minecraft:piston	extended=true;facing=north
539	minecraft:piston	extended=true;facing=south
540	minecraft:piston	extended=true;facing=west
541	minecraft:piston	extended=true;facing=east
544	minecraft:piston_head	facing=down;short=false;type=normal
545	minecraft:piston_head	facing=up;short=false;type=normal
546	minecraft:piston_head	facing=north;short=false;type=normal
547	minecraft:piston_head	facing=south;short=false;type=normal
548	minecraft:piston_head	facing=west;short=false;type=normal
549	minecraft:piston_head	facing=east;short=false;type=normal
552	minecraft:piston_head	facing=down;short=false;type=sticky
553	minecraft:piston_head	facing=up;short=false;type=sticky
554	minecraft:piston_head	facing=north;short=false;type=sticky
555	minecraft:piston_head	facing=south;short=false;type=sticky
556	minecraft:piston_head	facing=west;short=false;type=sticky
557	minecraft:piston_head	facing=east;short=false;type=sticky
560	minecraft:white_wool	
561	minecraft:orange_wool	
562	minecraft:magenta_wool	
563	minecraft:light_blue_wool	
564	minecraft:yellow_wool	
565	minecraft:lime_wool	
566	minecraft:pink_wool	
567	minecraft:gray_wool	
568	minecraft:light_gray_wool	
569	minecraft:cyan_wool	
570	minecraft:purple_wool	
571	minecraft:blue_wool	
572	minecraft:brown_wool	
573	minecraft:green_wool	
574	minecraft:red_wool	
575	minecraft:black_wool	
576	minecraft:moving_piston	facing=down;type=normal
577	minecraft:moving_piston	facing=up;type=normal
578	minecraft:moving_piston	facing=north;type=normal
579	minecraft:moving_piston	facing=south;type=normal
580	minecraft:moving_piston	facing=west;type=normal
581	minecraft:moving_piston	facing=east;type=normal
584	minecraft:moving_piston	facing=down;type=sticky
585	minecraft:moving_piston	facing=up;type=sticky
586	minecraft:moving_piston	facing=north;type=sticky
587	minecraft:moving_piston	facing=south;type=sticky
588	minecraft:moving_piston	facing=west;type=sticky
589	minecraft:moving_piston	facing=east;type=sticky
592	minecraft:dandelion	
608	minecraft:poppy	
609	minecraft:blue_orchid	
610	minecraft:allium	
611	minecraft:azure_bluet	
612	minecraft:red_tulip	
613	minecraft:orange_tulip	
614	minecraft:white_tulip	
615	minecraft:pink_tulip	
616	minecraft:oxeye_daisy	
624	minecraft:brown_mushroom	
640	minecraft:red_mushroom	
656	minecraft:gold_block	
672	minecraft:iron_block	
688	minecraft:stone_slab	type=double
689	minecraft:sandstone_slab	type=double
690	minecraft:petrified_oak_slab	type=double
691	minecraft:cobblestone_slab	type=double
692	minecraft:brick_slab	type=double
693	minecraft:stone_brick_slab	type=double
694	minecraft:nether_brick_slab	type=double
695	minecraft:quartz_slab	type=double
696	minecraft:smooth_stone	
697	minecraft:smooth_sandstone	
698	minecraft:petrified_oak_slab	type=double
699	minecraft:cobblestone_slab	type=double
700	minecraft:brick_slab	type=double
701	minecraft:stone_brick_slab	type=double
702	minecraft:nether_brick_slab	type=double
703	minecraft:smooth_quartz	
704	minecraft:stone_slab	type=bottom
705	minecraft:sandstone_slab	type=bottom
706	minecraft:petrified_oak_slab	type=bottom
707	minecraft:cobblestone_slab	type=bottom
708	minecraft:brick_slab	type=bottom
709	minecraft:stone_brick_slab	type=bottom
710	minecraft:nether_brick_slab	type=bottom
711	minecraft:quartz_slab	type=bottom
712	minecraft:stone_slab	type=top
713	minecraft:sandstone_slab	type=top
714	minecraft:petrified_oak_slab	type=top
715	minecraft:cobblestone_slab	type=top
716	minecraft:brick_slab	type=top
717	minecraft:stone_brick_slab	type=top
718	minecraft:nether_brick_slab	type=top
719	minecraft:quartz_slab	type=top
720	minecraft:bricks	
736	minecraft:tnt	unstable=false
737	minecraft:tnt	unstable=true
752	minecraft:bookshelf	
768	minecraft:mossy_cobblestone	
784	minecraft:obsidian	
801	minecraft:wall_torch	facing=east
802	minecraft:wall_torch	facing=west
803	minecraft:wall_torch	facing=south
804	minecraft:wall_torch	facing=north
805	minecraft:torch	
816	minecraft:fire	age=0;east=false;north=false;south=false;up=false;west=false
817	minecraft:fire	age=1;east=false;north=false;south=false;up=false;west=false
818	minecraft:fire	age=2;east=false;north=false;south=false;up=false;west=false
819	minecraft:fire	age=3;east=false;north=false;south=false;up=false;west=false
820	minecraft:fire	age=4;east=false;north=false;south=false;up=false;west=false
821	minecraft:fire	age=5;east=false;north=false;south=false;up=false;west=false
822	minecraft:fire	age=6;east=false;north=false;south=false;up=false;west=false
823	minecraft:fire	age=7;east=false;north=false;south=false;up=false;west=false
824	minecraft:fire	age=8;east=false;north=false;south=false;up=false;west=false
825	minecraft:fire	age=9;east=false;north=false;south=false;up=false;west=false
826	minecraft:fire	age=10;east=false;north=false;south=false;up=false;west=false
827	minecraft:fire	age=11;east=false;north=false;south=false;up=false;west=false
828	minecraft:fire	age=12;east=false;north=false;south=false;up=false;west=false
829	minecraft:fire	age=13;east=false;north=false;south=false;up=false;west=false
830	minecraft:fire	age=14;east=false;north=false;south=false;up=false;west=false
831	minecraft:fire	age=15;east=false;north=false;south=false;up=false;west=false
832	minecraft:mob_spawner	
848	minecraft:oak_stairs	facing=east;half=bottom;shape=straight
849	minecraft:oak_stairs	facing=west;half=bottom;shape=straight
850	minecraft:oak_stairs	facing=south;half=bottom;shape=straight
851	minecraft:oak_stairs	facing=north;half=bottom;shape=straight
852	minecraft:oak_stairs	facing=east;half=top;shape=straight
853	minecraft:oak_stairs	facing=west;half=top;shape=straight
854	minecraft:oak_stairs	facing=south;half=top;shape=straight
855	minecraft:oak_stairs	facing=north;half=top;shape=straight
866	minecraft:chest	facing=north;type=single
867	minecraft:chest	facing=south;type=single
868	minecraft:chest	facing=west;type=single
869	minecraft:chest	facing=east;type=single
880	minecraft:redstone_wire	east=none;north=none;power=0;south=none;west=none
881	minecraft:redstone_wire	east=none;north=none;power=1;south=none;west=none
882	minecraft:redstone_wire	east=none;north=none;power=2;south=none;west=none
883	minecraft:redstone_wire	east=none;north=none;power=3;south=none;west=none
884	minecraft:redstone_wire	east=none;north=none;power=4;south=none;west=none
885	minecraft:redstone_wire	east=none;north=none;power=5;south=none;west=none
886	minecraft:redstone_wire	east=none;north=none;power=6;south=none;west=none
887	minecraft:redstone_wire	east=none;north=none;power=7;south=none;west=none
888	minecraft:redstone_wire	east=none;north=none;power=8;south=none;west=none
889	minecraft:redstone_wire	east=none;north=none;power=9;south=none;west=none
890	minecraft:redstone_wire	east=none;north=none;power=10;south=none;west=none
891	minecraft:redstone_wire	east=none;north=none;power=11;south=none;west=none
892	minecraft:redstone_wire	east=none;north=none;power=12;south=none;west=none
893	minecraft:redstone_wire	east=none;north=none;power=13;south=none;west=none
894	minecraft:redstone_wire	east=none;north=none;power=14;south=none;west=none
895	minecraft:redstone_wire	east=none;north=none;power=15;south=none;west=none
896	minecraft:diamond_ore	
912	minecraft:diamond_block	
928	minecraft:crafting_table	
944	minecraft:wheat	age=0
945	minecraft:wheat	age=1
946	minecraft:wheat	age=2
947	minecraft:wheat	age=3
948	minecraft:wheat	age=4
949	minecraft:wheat	age=5
950	minecraft:wheat	age=6
951	minecraft:wheat	age=7
960	minecraft:farmland	moisture=0
961	minecraft:farmland	moisture=1
962	minecraft:farmland	moisture=2
963	minecraft:farmland	moisture=3
964	minecraft:farmland	moisture=4
965	minecraft:farmland	moisture=5
966	minecraft:farmland	moisture=6
967	minecraft:farmland	moisture=7
978	minecraft:furnace	facing=north;lit=false
979	minecraft:furnace	facing=south;lit=false
980	minecraft:furnace	facing=west;lit=false
981	minecraft:furnace	facing=east;lit=false
994	minecraft:furnace	facing=north;lit=true
995	minecraft:furnace	facing=south;lit=true
996	minecraft:furnace	facing=west;lit=true
997	minecraft:furnace	facing=east;lit=true
1008	minecraft:sign	rotation=0
1009	minecraft:sign	rotation=1
1010	minecraft:sign	rotation=2
1011	minecraft:sign	rotation=3
1012	minecraft:sign	rotation=4
1013	minecraft:sign	rotation=5
1014	minecraft:sign	rotation=6
1015	minecraft:sign	rotation=7
1016	minecraft:sign	rotation=8
1017	minecraft:sign	rotation=9
1018	minecraft:sign	rotation=10
1019	minecraft:sign	rotation=11
1020	minecraft:sign	rotation=12
1021	minecraft:sign	rotation=13
1022	minecraft:sign	rotation=14
1023	minecraft:sign	rotation=15
1024	minecraft:oak_door	facing=east;half=lower;hinge=right;open=false;powered=false
1025	minecraft:oak_door	facing=south;half=lower;hinge=right;open=false;powered=false
1026	minecraft:oak_door	facing=west;half=lower;hinge=right;open=false;powered=false
1027	minecraft:oak_door	facing=north;half=lower;hinge=right;open=false;powered=false
1028	minecraft:oak_door	facing=east;half=lower;hinge=right;open=true;powered=false
1029	minecraft:oak_door	facing=south;half=lower;hinge=right;open=true;powered=false
1030	minecraft:oak_door	facing=west;half=lower;hinge=right;open=true;powered=false
1031	minecraft:oak_door	facing=north;half=lower;hinge=right;open=true;powered=false
1032	minecraft:oak_door	facing=east;half=upper;hinge=left;open=false;powered=false
1033	minecraft:oak_door	facing=east;half=upper;hinge=right;open=false;powered=false
1034	minecraft:oak_door	facing=east;half=upper;hinge=left;open=false;powered=true
1035	minecraft:oak_door	facing=east;half=upper;hinge=right;open=false;powered=true
1036	minecraft:oak_door	facing=east;half=upper;hinge=left;open=true;powered=false
1037	minecraft:oak_door	facing=south;half=upper;hinge=left;open=true;powered=false
1038	minecraft:oak_door	facing=west;half=upper;hinge=left;open=true;powered=false
1039	minecraft:oak_door	facing=north;half=upper;hinge=left;open=true;powered=false
1042	minecraft:ladder	facing=north
1043	minecraft:ladder	facing=south
1044	minecraft:ladder	facing=west
1045	minecraft:ladder	facing=east
1056	minecraft:rail	shape=north_south
1057	minecraft:rail	shape=east_west
1058	minecraft:rail	shape=ascending_east
1059	minecraft:rail	shape=ascending_west
1060	minecraft:rail	shape=ascending_north
1061	minecraft:rail	shape=ascending_south
1062	minecraft:rail	shape=south_east
1063	minecraft:rail	shape=south_west
1064	minecraft:rail	shape=north_west
1065	minecraft:rail	shape=north_east
1072	minecraft:cobblestone_stairs	facing=east;half=bottom;shape=straight
1073	minecraft:cobblestone_stairs	facing=west;half=bottom;shape=straight
1074	minecraft:cobblestone_stairs	facing=south;half=bottom;shape=straight
1075	minecraft:cobblestone_stairs	facing=north;half=bottom;shape=straight
1076	minecraft:cobblestone_stairs	facing=east;half=top;shape=straight
1077	minecraft:cobblestone_stairs	facing=west;half=top;shape=straight
1078	minecraft:cobblestone_stairs	facing=south;half=top;shape=straight
1079	minecraft:cobblestone_stairs	facing=north;half=top;shape=straight
1090	minecraft:wall_sign	facing=north
1091	minecraft:wall_sign	facing=south
1092	minecraft:wall_sign	facing=west
1093	minecraft:wall_sign	facing=east
1104	minecraft:lever	face=ceiling;facing=west;powered=false
1105	minecraft:lever	face=wall;facing=east;powered=false
1106	minecraft:lever	face=wall;facing=west;powered=false
1107	minecraft:lever	face=wall;facing=south;powered=false
1108	minecraft:lever	face=wall;facing=north;powered=false
1109	minecraft:lever	face=floor;facing=north;powered=false
1110	minecraft:lever	face=floor;facing=west;powered=false
1111	minecraft:lever	face=ceiling;facing=north;powered=false
1112	minecraft:lever	face=ceiling;facing=west;powered=true
1113	minecraft:lever	face=wall;facing=east;powered=true
1114	minecraft:lever	face=wall;facing=west;powered=true
1115	minecraft:lever	face=wall;facing=south;powered=true
1116	minecraft:lever	face=wall;facing=north;powered=true
1117	minecraft:lever	face=floor;facing=north;powered=true
1118	minecraft:lever	face=floor;facing=west;powered=true
1119	minecraft:lever	face=ceiling;facing=north;powered=true
1120	minecraft:stone_pressure_plate	powered=false
1121	minecraft:stone_pressure_plate	powered=true
1136	minecraft:iron_door	facing=east;half=lower;hinge=right;open=false;powered=false
1137	minecraft:iron_door	facing=south;half=lower;hinge=right;open=false;powered=false
1138	minecraft:iron_door	facing=west;half=lower;hinge=right;open=false;powered=false
1139	minecraft:iron_door	facing=north;half=lower;hinge=right;open=false;powered=false
1140	minecraft:iron_door	facing=east;half=lower;hinge=right;open=true;powered=false
1141	minecraft:iron_door	facing=south;half=lower;hinge=right;open=true;powered=false
1142	minecraft:iron_door	facing=west;half=lower;hinge=right;open=true;powered=false
1143	minecraft:iron_door	facing=north;half=lower;hinge=right;open=true;powered=false
1144	minecraft:iron_door	facing=east;half=upper;hinge=left;open=false;powered=false
1145	minecraft:iron_door	facing=east;half=upper;hinge=right;open=false;powered=false
1146	minecraft:iron_door	facing=east;half=upper;hinge=left;open=false;powered=true
1147	minecraft:iron_door	facing=east;half=upper;hinge=right;open=false;powered=true
1148	minecraft:iron_door	facing=east;half=upper;hinge=left;open=true;powered=false
1149	minecraft:iron_door	facing=south;half=upper;hinge=left;open=true;powered=false
1150	minecraft:iron_door	facing=west;half=upper;hinge=left;open=true;powered=false
1151	minecraft:iron_door	facing=north;half=upper;hinge=left;open=true;powered=false
1152	minecraft:oak_pressure_plate	powered=false
1153	minecraft:oak_pressure_plate	powered=true
1168	minecraft:redstone_ore	lit=false
1184	minecraft:redstone_ore	lit=true
1201	minecraft:redstone_wall_torch	facing=east;lit=false
1202	minecraft:redstone_wall_torch	facing=west;lit=false
1203	minecraft:redstone_wall_torch	facing=south;lit=false
1204	minecraft:redstone_wall_torch	facing=north;lit=false
1205	minecraft:redstone_torch	lit=false
1217	minecraft:redstone_wall_torch	facing=east;lit=true
1218	minecraft:redstone_wall_torch	facing=west;lit=true
1219	minecraft:redstone_wall_torch	facing=south;lit=true
1220	minecraft:redstone_wall_torch	facing=north;lit=true
1221	minecraft:redstone_torch	lit=true
1232	minecraft:stone_button	face=ceiling;facing=north;powered=false
1233	minecraft:stone_button	face=wall;facing=east;powered=false
1234	minecraft:stone_button	face=wall;facing=west;powered=false
1235	minecraft:stone_button	face=wall;facing=south;powered=false
1236	minecraft:stone_button	face=wall;facing=north;powered=false
1237	minecraft:stone_button	face=floor;facing=north;powered=false
1240	minecraft:stone_button	face=ceiling;facing=north;powered=true
1241	minecraft:stone_button	face=wall;facing=east;powered=true
1242	minecraft:stone_button	face=wall;facing=west;powered=true
1243	minecraft:stone_button	face=wall;facing=south;powered=true
1244	minecraft:stone_button	face=wall;facing=north;powered=true
1245	minecraft:stone_button	face=floor;facing=north;powered=true
1248	minecraft:snow	layers=1
1249	minecraft:snow	layers=2
1250	minecraft:snow	layers=3
1251	minecraft:snow	layers=4
1252	minecraft:snow	layers=5
1253	minecraft:snow	layers=6
1254	minecraft:snow	layers=7
1255	minecraft:snow	layers=8
1264	minecraft:ice	
1280	minecraft:snow_block	
1296	minecraft:cactus	age=0
1297	minecraft:cactus	age=1
1298	minecraft:cactus	age=2
1299	minecraft:cactus	age=3
1300	minecraft:cactus	age=4
1301	minecraft:cactus	age=5
1302	minecraft:cactus	age=6
1303	minecraft:cactus	age=7
1304	minecraft:cactus	age=8
1305	minecraft:cactus	age=9
1306	minecraft:cactus	age=10
1307	minecraft:cactus	age=11
1308	minecraft:cactus	age=12
1309	minecraft:cactus	age=13
1310	minecraft:cactus	age=14
1311	minecraft:cactus	age=15
1312	minecraft:clay	
1328	minecraft:sugar_cane	age=0
1329	minecraft:sugar_cane	age=1
1330	minecraft:sugar_cane	age=2
1331	minecraft:sugar_cane	age=3
1332	minecraft:sugar_cane	age=4
1333	minecraft:sugar_cane	age=5
1334	minecraft:sugar_cane	age=6
1335	minecraft:sugar_cane	age=7
1336	minecraft:sugar_cane	age=8
1337	minecraft:sugar_cane	age=9
1338	minecraft:sugar_cane	age=10
1339	minecraft:sugar_cane	age=11
1340	minecraft:sugar_cane	age=12
1341	minecraft:sugar_cane	age=13
1342	minecraft:sugar_cane	age=14
1343	minecraft:sugar_cane	age=15
1344	minecraft:jukebox	has_record=false
1345	minecraft:jukebox	has_record=true
1360	minecraft:oak_fence	east=false;north=false;south=false;west=false
1376	minecraft:carved_pumpkin	facing=south
1377	minecraft:carved_pumpkin	facing=west
1378	minecraft:carved_pumpkin	facing=north
1379	minecraft:carved_pumpkin	facing=east
1392	minecraft:netherrack	
1408	minecraft:soul_sand	
1424	minecraft:glowstone	
1441	minecraft:portal	axis=x
1442	minecraft:portal	axis=z
1456	minecraft:jack_o_lantern	facing=south
1457	minecraft:jack_o_lantern	facing=west
1458	minecraft:jack_o_lantern	facing=north
1459	minecraft:jack_o_lantern	facing=east
1472	minecraft:cake	bites=0
1473	minecraft:cake	bites=1
1474	minecraft:cake	bites=2
1475	minecraft:cake	bites=3
1476	minecraft:cake	bites=4
1477	minecraft:cake	bites=5
1478	minecraft:cake	bites=6
1488	minecraft:repeater	delay=1;facing=south;locked=false;powered=false
1489	minecraft:repeater	delay=1;facing=west;locked=false;powered=false
1490	minecraft:repeater	delay=1;facing=north;locked=false;powered=false
1491	minecraft:repeater	delay=1;facing=east;locked=false;powered=false
1492	minecraft:repeater	delay=2;facing=south;locked=false;powered=false
1493	minecraft:repeater	delay=2;facing=west;locked=false;powered=false
1494	minecraft:repeater	delay=2;facing=north;locked=false;powered=false
1495	minecraft:repeater	delay=2;facing=east;locked=false;powered=false
1496	minecraft:repeater	delay=3;facing=south;locked=false;powered=false
1497	minecraft:repeater	delay=3;facing=west;locked=false;powered=false
1498	minecraft:repeater	delay=3;facing=north;locked=false;powered=false
1499	minecraft:repeater	delay=3;facing=east;locked=false;powered=false
1500	minecraft:repeater	delay=4;facing=south;locked=false;powered=false
1501	minecraft:repeater	delay=4;facing=west;locked=false;powered=false
1502	minecraft:repeater	delay=4;facing=north;locked=false;powered=false
1503	minecraft:repeater	delay=4;facing=east;locked=false;powered=false
1504	minecraft:repeater	delay=1;facing=south;locked=false;powered=true
1505	minecraft:repeater	delay=1;facing=west;locked=false;powered=true
1506	minecraft:repeater	delay=1;facing=north;locked=false;powered=true
1507	minecraft:repeater	delay=1;facing=east;locked=false;powered=true
1508	minecraft:repeater	delay=2;facing=south;locked=false;powered=true
1509	minecraft:repeater	delay=2;facing=west;locked=false;powered=true
1510	minecraft:repeater	delay=2;facing=north;locked=false;powered=true
1511	minecraft:repeater	delay=2;facing=east;locked=false;powered=true
1512	minecraft:repeater	delay=3;facing=south;locked=false;powered=true
1513	minecraft:repeater	delay=3;facing=west;locked=false;powered=true
1514	minecraft:repeater	delay=3;facing=north;locked=false;powered=true
1515	minecraft:repeater	delay=3;facing=east;locked=false;powered=true
1516	minecraft:repeater	delay=4;facing=south;locked=false;powered=true
1517	minecraft:repeater	delay=4;facing=west;locked=false;powered=true
1518	minecraft:repeater	delay=4;facing=north;locked=false;powered=true
1519	minecraft:repeater	delay=4;facing=east;locked=false;powered=true
1520	minecraft:white_stained_glass	
1521	minecraft:orange_stained_glass	
1522	minecraft:magenta_stained_glass	
1523	minecraft:light_blue_stained_glass	
1524	minecraft:yellow_stained_glass	
1525	minecraft:lime_stained_glass	
1526	minecraft:pink_stained_glass	
1527	minecraft:gray_stained_glass	
1528	minecraft:light_gray_stained_glass	
1529	minecraft:cyan_stained_glass	
1530	minecraft:purple_stained_glass	
1531	minecraft:blue_stained_glass	
1532	minecraft:brown_stained_glass	
1533	minecraft:green_stained_glass	
1534	minecraft:red_stained_glass	
1535	minecraft:black_stained_glass	
1536	minecraft:oak_trapdoor	facing=north;half=bottom;open=false
1537	minecraft:oak_trapdoor	facing=south;half=bottom;open=false
1538	minecraft:oak_trapdoor	facing=west;half=bottom;open=false
1539	minecraft:oak_trapdoor	facing=east;half=bottom;open=false
1540	minecraft:oak_trapdoor	facing=north;half=bottom;open=true
1541	minecraft:oak_trapdoor	facing=south;half=bottom;open=true
1542	minecraft:oak_trapdoor	facing=west;half=bottom;open=true
1543	minecraft:oak_trapdoor	facing=east;half=bottom;open=true
1544	minecraft:oak_trapdoor	facing=north;half=top;open=false
1545	minecraft:oak_trapdoor	facing=south;half=top;open=false
1546	minecraft:oak_trapdoor	facing=west;half=top;open=false
1547	minecraft:oak_trapdoor	facing=east;half=top;open=false
1548	minecraft:oak_trapdoor	facing=north;half=top;open=true
1549	minecraft:oak_trapdoor	facing=south;half=top;open=true
1550	minecraft:oak_trapdoor	facing=west;half=top;open=true
1551	minecraft:oak_trapdoor	facing=east;half=top;open=true
1552	minecraft:infested_stone	
1553	minecraft:infested_cobblestone	
1554	minecraft:infested_stone_bricks	
1555	minecraft:infested_mossy_stone_bricks	
1556	minecraft:infested_cracked_stone_bricks	
1557	minecraft:infested_chiseled_stone_bricks	
1568	minecraft:stone_bricks	
1569	minecraft:mossy_stone_bricks	
1570	minecraft:cracked_stone_bricks	
1571	minecraft:chiseled_stone_bricks	
1584	minecraft:brown_mushroom_block	down=false;east=false;north=false;south=false;up=false;west=false
1585	minecraft:brown_mushroom_block	down=false;east=false;north=true;south=false;up=true;west=true
1586	minecraft:brown_mushroom_block	down=false;east=false;north=true;south=false;up=true;west=false
1587	minecraft:brown_mushroom_block	down=false;east=true;north=true;south=false;up=true;west=false
1588	minecraft:brown_mushroom_block	down=false;east=false;north=false;south=false;up=true;west=true
1589	minecraft:brown_mushroom_block	down=false;east=false;north=false;south=false;up=true;west=false
1590	minecraft:brown_mushroom_block	down=false;east=true;north=false;south=false;up=true;west=false
1591	minecraft:brown_mushroom_block	down=false;east=false;north=false;south=true;up=true;west=true
1592	minecraft:brown_mushroom_block	down=false;east=false;north=false;south=true;up=true;west=false
1593	minecraft:brown_mushroom_block	down=false;east=true;north=false;south=true;up=true;west=false
1594	minecraft:mushroom_stem	down=false;east=true;north=true;south=true;up=false;west=true
1595	minecraft:brown_mushroom_block	down=false;east=false;north=false;south=false;up=false;west=false
1596	minecraft:brown_mushroom_block	down=false;east=false;north=false;south=false;up=false;west=false
1597	minecraft:brown_mushroom_block	down=false;east=false;north=false;south=false;up=false;west=false
1598	minecraft:brown_mushroom_block	down=true;east=true;north=true;south=true;up=true;west=true
1599	minecraft:mushroom_stem	down=true;east=true;north=true;south=true;up=true;west=true
1600	minecraft:red_mushroom_block	down=false;east=false;north=false;south=false;up=false;west=false
1601	minecraft:red_mushroom_block	down=false;east=false;north=true;south=false;up=true;west=true
1602	minecraft:red_mushroom_block	down=false;east=false;north=true;south=false;up=true;west=false
1603	minecraft:red_mushroom_block	down=false;east=true;north=true;south=false;up=true;west=false
1604	minecraft:red_mushroom_block	down=false;east=false;north=false;south=false;up=true;west=true
1605	minecraft:red_mushroom_block	down=false;east=false;north=false;south=false;up=true;west=false
1606	minecraft:red_mushroom_block	down=false;east=true;north=false;south=false;up=true;west=false
1607	minecraft:red_mushroom_block	down=false;east=false;north=false;south=true;up=true;west=true
1608	minecraft:red_mushroom_block	down=false;east=false;north=false;south=true;up=true;west=false
1609	minecraft:red_mushroom_block	down=false;east=true;north=false;south=true;up=true;west=false
1610	minecraft:mushroom_stem	down=false;east=true;north=true;south=true;up=false;west=true
1611	minecraft:red_mushroom_block	down=false;east=false;north=false;south=false;up=false;west=false
1612	minecraft:red_mushroom_block	down=false;east=false;north=false;south=false;up=false;west=false
1613	minecraft:red_mushroom_block	down=false;east=false;north=false;south=false;up=false;west=false
1614	minecraft:red_mushroom_block	down=true;east=true;north=true;south=true;up=true;west=true
1615	minecraft:mushroom_stem	down=true;east=true;north=true;south=true;up=true;west=true
1616	minecraft:iron_bars	east=false;north=false;south=false;west=false
1632	minecraft:glass_pane	east=false;north=false;south=false;west=false
1648	minecraft:melon_block	
1664	minecraft:pumpkin_stem	age=0
1665	minecraft:pumpkin_stem	age=1
1666	minecraft:pumpkin_stem	age=2
1667	minecraft:pumpkin_stem	age=3
1668	minecraft:pumpkin_stem	age=4
1669	minecraft:pumpkin_stem	age=5
1670	minecraft:pumpkin_stem	age=6
1671	minecraft:pumpkin_stem	age=7
1680	minecraft:melon_stem	age=0
1681	minecraft:melon_stem	age=1
1682	minecraft:melon_stem	age=2
1683	minecraft:melon_stem	age=3
1684	minecraft:melon_stem	age=4
1685	minecraft:melon_stem	age=5
1686	minecraft:melon_stem	age=6
1687	minecraft:melon_stem	age=7
1696	minecraft:vine	east=false;north=false;south=false;up=true;west=false
1697	minecraft:vine	east=false;north=false;south=true;up=true;west=false
1698	minecraft:vine	east=false;north=false;south=false;up=true;west=true
1699	minecraft:vine	east=false;north=false;south=true;up=true;west=true
1700	minecraft:vine	east=false;north=true;south=false;up=true;west=false
1701	minecraft:vine	east=false;north=true;south=true;up=true;west=false
1702	minecraft:vine	east=false;north=true;south=false;up=true;west=true
1703	minecraft:vine	east=false;north=true;south=true;up=true;west=true
1704	minecraft:vine	east=true;north=false;south=false;up=true;west=false
1705	minecraft:vine	east=true;north=false;south=true;up=true;west=false
1706	minecraft:vine	east=true;north=false;south=false;up=true;west=true
1707	minecraft:vine	east=true;north=false;south=true;up=true;west=true
1708	minecraft:vine	east=true;north=true;south=false;up=true;west=false
1709	minecraft:vine	east=true;north=true;south=true;up=true;west=false
1710	minecraft:vine	east=true;north=true;south=false;up=true;west=true
1711	minecraft:vine	east=true;north=true;south=true;up=true;west=true
1712	minecraft:oak_fence_gate	facing=south;in_wall=false;open=false;powered=false
1713	minecraft:oak_fence_gate	facing=west;in_wall=false;open=false;powered=false
1714	minecraft:oak_fence_gate	facing=north;in_wall=false;open=false;powered=false
1715	minecraft:oak_fence_gate	facing=east;in_wall=false;open=false;powered=false
1716	minecraft:oak_fence_gate	facing=south;in_wall=false;open=true;powered=false
1717	minecraft:oak_fence_gate	facing=west;in_wall=false;open=true;powered=false
1718	minecraft:oak_fence_gate	facing=north;in_wall=false;open=true;powered=false
1719	minecraft:oak_fence_gate	facing=east;in_wall=false;open=true;powered=false
1720	minecraft:oak_fence_gate	facing=south;in_wall=false;open=false;powered=true
1721	minecraft:oak_fence_gate	facing=west;in_wall=false;open=false;powered=true
1722	minecraft:oak_fence_gate	facing=north;in_wall=false;open=false;powered=true
1723	minecraft:oak_fence_gate	facing=east;in_wall=false;open=false;powered=true
1724	minecraft:oak_fence_gate	facing=south;in_wall=false;open=true;powered=true
1725	minecraft:oak_fence_gate	facing=west;in_wall=false;open=true;powered=true
1726	minecraft:oak_fence_gate	facing=north;in_wall=false;open=true;powered=true
1727	minecraft:oak_fence_gate	facing=east;in_wall=false;open=true;powered=true
1728	minecraft:brick_stairs	facing=east;half=bottom;shape=straight
1729	minecraft:brick_stairs	facing=west;half=bottom;shape=straight
1730	minecraft:brick_stairs	facing=south;half=bottom;shape=straight
1731	minecraft:brick_stairs	facing=north;half=bottom;shape=straight
1732	minecraft:brick_stairs	facing=east;half=top;shape=straight
1733	minecraft:brick_stairs	facing=west;half=top;shape=straight
1734	minecraft:brick_stairs	facing=south;half=top;shape=straight
1735	minecraft:brick_stairs	facing=north;half=top;shape=straight
1744	minecraft:stone_brick_stairs	facing=east;half=bottom;shape=straight
1745	minecraft:stone_brick_stairs	facing=west;half=bottom;shape=straight
1746	minecraft:stone_brick_stairs	facing=south;half=bottom;shape=straight
1747	minecraft:stone_brick_stairs	facing=north;half=bottom;shape=straight
1748	minecraft:stone_brick_stairs	facing=east;half=top;shape=straight
1749	minecraft:stone_brick_stairs	facing=west;half=top;shape=straight
1750	minecraft:stone_brick_stairs	facing=south;half=top;shape=straight
1751	minecraft:stone_brick_stairs	facing=north;half=top;shape=straight
1760	minecraft:mycelium	snowy=false
1776	minecraft:lily_pad	
1792	minecraft:nether_bricks	
1808	minecraft:nether_brick_fence	east=false;north=false;south=false;west=false
1824	minecraft:nether_brick_stairs	facing=east;half=bottom;shape=straight
1825	minecraft:nether_brick_stairs	facing=west;half=bottom;shape=straight
1826	minecraft:nether_brick_stairs	facing=south;half=bottom;shape=straight
1827	minecraft:nether_brick_stairs	facing=north;half=bottom;shape=straight
1828	minecraft:nether_brick_stairs	facing=east;half=top;shape=straight
1829	minecraft:nether_brick_stairs	facing=west;half=top;shape=straight
1830	minecraft:nether_brick_stairs	facing=south;half=top;shape=straight
1831	minecraft:nether_brick_stairs	facing=north;half=top;shape=straight
1840	minecraft:nether_wart	age=0
1841	minecraft:nether_wart	age=1
1842	minecraft:nether_wart	age=2
1843	minecraft:nether_wart	age=3
1856	minecraft:enchanting_table	
1872	minecraft:brewing_stand	has_bottle_0=false;has_bottle_1=false;has_bottle_2=false
1873	minecraft:brewing_stand	has_bottle_0=true;has_bottle_1=false;has_bottle_2=false
1874	minecraft:brewing_stand	has_bottle_0=false;has_bottle_1=true;has_bottle_2=false
1875	minecraft:brewing_stand	has_bottle_0=true;has_bottle_1=true;has_bottle_2=false
1876	minecraft:brewing_stand	has_bottle_0=false;has_bottle_1=false;has_bottle_2=true
1877	minecraft:brewing_stand	has_bottle_0=true;has_bottle_1=false;has_bottle_2=true
1878	minecraft:brewing_stand	has_bottle_0=false;has_bottle_1=true;has_bottle_2=true
1879	minecraft:brewing_stand	has_bottle_0=true;has_bottle_1=true;has_bottle_2=true
1888	minecraft:cauldron	level=0
1889	minecraft:cauldron	level=1
1890	minecraft:cauldron	level=2
1891	minecraft:cauldron	level=3
1904	minecraft:end_portal	
1920	minecraft:end_portal_frame	eye=false;facing=south
1921	minecraft:end_portal_frame	eye=false;facing=west
1922	minecraft:end_portal_frame	eye=false;facing=north
1923	minecraft:end_portal_frame	eye=false;facing=east
1924	minecraft:end_portal_frame	eye=true;facing=south
1925	minecraft:end_portal_frame	eye=true;facing=west
1926	minecraft:end_portal_frame	eye=true;facing=north
1927	minecraft:end_portal_frame	eye=true;facing=east
1936	minecraft:end_stone	
1952	minecraft:dragon_egg	
1968	minecraft:redstone_lamp	lit=false
1984	minecraft:redstone_lamp	lit=true
2000	minecraft:oak_slab	type=double
2001	minecraft:spruce_slab	type=double
2002	minecraft:birch_slab	type=double
2003	minecraft:jungle_slab	type=double
2004	minecraft:acacia_slab	type=double
2005	minecraft:dark_oak_slab	type=double
2016	minecraft:oak_slab	type=bottom
2017	minecraft:spruce_slab	type=bottom
2018	minecraft:birch_slab	type=bottom
2019	minecraft:jungle_slab	type=bottom
2020	minecraft:acacia_slab	type=bottom
2021	minecraft:dark_oak_slab	type=bottom
2024	minecraft:oak_slab	type=top
2025	minecraft:spruce_slab	type=top
2026	minecraft:birch_slab	type=top
2027	minecraft:jungle_slab	type=top
2028	minecraft:acacia_slab	type=top
2029	minecraft:dark_oak_slab	type=top
2032	minecraft:cocoa	age=0;facing=south
2033	minecraft:cocoa	age=0;facing=west
2034	minecraft:cocoa	age=0;facing=north
2035	minecraft:cocoa	age=0;facing=east
2036	minecraft:cocoa	age=1;facing=south
2037	minecraft:cocoa	age=1;facing=west
2038	minecraft:cocoa	age=1;facing=north
2039	minecraft:cocoa	age=1;facing=east
2040	minecraft:cocoa	age=2;facing=south
2041	minecraft:cocoa	age=2;facing=west
2042	minecraft:cocoa	age=2;facing=north
2043	minecraft:cocoa	age=2;facing=east
2048	minecraft:sandstone_stairs	facing=east;half=bottom;shape=straight
2049	minecraft:sandstone_stairs	facing=west;half=bottom;shape=straight
2050	minecraft:sandstone_stairs	facing=south;half=bottom;shape=straight
2051	minecraft:sandstone_stairs	facing=north;half=bottom;shape=straight
2052	minecraft:sandstone_stairs	facing=east;half=top;shape=straight
2053	minecraft:sandstone_stairs	facing=west;half=top;shape=straight
2054	minecraft:sandstone_stairs	facing=south;half=top;shape=straight
2055	minecraft:sandstone_stairs	facing=north;half=top;shape=straight
2064	minecraft:emerald_ore	
2082	minecraft:ender_chest	facing=north
2083	minecraft:ender_chest	facing=south
2084	minecraft:ender_chest	facing=west
2085	minecraft:ender_chest	facing=east
2096	minecraft:tripwire_hook	attached=false;facing=south;powered=false
2097	minecraft:tripwire_hook	attached=false;facing=west;powered=false
2098	minecraft:tripwire_hook	attached=false;facing=north;powered=false
2099	minecraft:tripwire_hook	attached=false;facing=east;powered=false
2100	minecraft:tripwire_hook	attached=true;facing=south;powered=false
2101	minecraft:tripwire_hook	attached=true;facing=west;powered=false
2102	minecraft:tripwire_hook	attached=true;facing=north;powered=false
2103	minecraft:tripwire_hook	attached=true;facing=east;powered=false
2104	minecraft:tripwire_hook	attached=false;facing=south;powered=true
2105	minecraft:tripwire_hook	attached=false;facing=west;powered=true
2106	minecraft:tripwire_hook	attached=false;facing=north;powered=true
2107	minecraft:tripwire_hook	attached=false;facing=east;powered=true
2108	minecraft:tripwire_hook	attached=true;facing=south;powered=true
2109	minecraft:tripwire_hook	attached=true;facing=west;powered=true
2110	minecraft:tripwire_hook	attached=true;facing=north;powered=true
2111	minecraft:tripwire_hook	attached=true;facing=east;powered=true
2112	minecraft:tripwire	attached=false;disarmed=false;east=false;north=false;powered=false;south=false;west=false
2113	minecraft:tripwire	attached=false;disarmed=false;east=false;north=false;powered=true;south=false;west=false
2114	minecraft:tripwire	attached=false;disarmed=false;east=false;north=false;powered=false;south=false;west=false
2115	minecraft:tripwire	attached=false;disarmed=false;east=false;north=false;powered=true;south=false;west=false
2116	minecraft:tripwire	attached=true;disarmed=false;east=false;north=false;powered=false;south=false;west=false
2117	minecraft:tripwire	attached=true;disarmed=false;east=false;north=false;powered=true;south=false;west=false
2118	minecraft:tripwire	attached=true;disarmed=false;east=false;north=false;powered=false;south=false;west=false
2119	minecraft:tripwire	attached=true;disarmed=false;east=false;north=false;powered=true;south=false;west=false
2120	minecraft:tripwire	attached=false;disarmed=true;east=false;north=false;powered=false;south=false;west=false
2121	minecraft:tripwire	attached=false;disarmed=true;east=false;north=false;powered=true;south=false;west=false
2122	minecraft:tripwire	attached=false;disarmed=true;east=false;north=false;powered=false;south=false;west=false
2123	minecraft:tripwire	attached=false;disarmed=true;east=false;north=false;powered=true;south=false;west=false
2124	minecraft:tripwire	attached=true;disarmed=true;east=false;north=false;powered=false;south=false;west=false
2125	minecraft:tripwire	attached=true;disarmed=true;east=false;north=false;powered=true;south=false;west=false
2126	minecraft:tripwire	attached=true;disarmed=true;east=false;north=false;powered=false;south=false;west=false
2128	minecraft:emerald_block	
2144	minecraft:spruce_stairs	facing=east;half=bottom;shape=straight
2145	minecraft:spruce_stairs	facing=west;half=bottom;shape=straight
2146	minecraft:spruce_stairs	facing=south;half=bottom;shape=straight
2147	minecraft:spruce_stairs	facing=north;half=bottom;shape=straight
2148	minecraft:spruce_stairs	facing=east;half=top;shape=straight
2149	minecraft:spruce_stairs	facing=west;half=top;shape=straight
2150	minecraft:spruce_stairs	facing=south;half=top;shape=straight
2151	minecraft:spruce_stairs	facing=north;half=top;shape=straight
2160	minecraft:birch_stairs	facing=east;half=bottom;shape=straight
2161	minecraft:birch_stairs	facing=west;half=bottom;shape=straight
2162	minecraft:birch_stairs	facing=south;half=bottom;shape=straight
2163	minecraft:birch_stairs	facing=north;half=bottom;shape=straight
2164	minecraft:birch_stairs	facing=east;half=top;shape=straight
2165	minecraft:birch_stairs	facing=west;half=top;shape=straight
2166	minecraft:birch_stairs	facing=south;half=top;shape=straight
2167	minecraft:birch_stairs	facing=north;half=top;shape=straight
2176	minecraft:jungle_stairs	facing=east;half=bottom;shape=straight
2177	minecraft:jungle_stairs	facing=west;half=bottom;shape=straight
2178	minecraft:jungle_stairs	facing=south;half=bottom;shape=straight
2179	minecraft:jungle_stairs	facing=north;half=bottom;shape=straight
2180	minecraft:jungle_stairs	facing=east;half=top;shape=straight
2181	minecraft:jungle_stairs	facing=west;half=top;shape=straight
2182	minecraft:jungle_stairs	facing=south;half=top;shape=straight
2183	minecraft:jungle_stairs	facing=north;half=top;shape=straight
2192	minecraft:command_block	conditional=false;facing=down
2193	minecraft:command_block	conditional=false;facing=up
2194	minecraft:command_block	conditional=false;facing=north
2195	minecraft:command_block	conditional=false;facing=south
2196	minecraft:command_block	conditional=false;facing=west
2197	minecraft:command_block	conditional=false;facing=east
2200	minecraft:command_block	conditional=true;facing=down
2201	minecraft:command_block	conditional=true;facing=up
2202	minecraft:command_block	conditional=true;facing=north
2203	minecraft:command_block	conditional=true;facing=south
2204	minecraft:command_block	conditional=true;facing=west
2205	minecraft:command_block	conditional=true;facing=east
2208	minecraft:beacon	
2224	minecraft:cobblestone_wall	east=false;north=false;south=false;up=false;west=false
2225	minecraft:mossy_cobblestone_wall	east=false;north=false;south=false;up=false;west=false
2240	minecraft:potted_cactus	
2241	minecraft:potted_cactus	
2242	minecraft:potted_cactus	
2243	minecraft:potted_cactus	
2244	minecraft:potted_cactus	
2245	minecraft:potted_cactus	
2246	minecraft:potted_cactus	
2247	minecraft:potted_cactus	
2248	minecraft:potted_cactus	
2249	minecraft:potted_cactus	
2250	minecraft:potted_cactus	
2251	minecraft:potted_cactus	
2252	minecraft:potted_cactus	
2253	minecraft:potted_cactus	
2254	minecraft:potted_cactus	
2255	minecraft:potted_cactus	
2256	minecraft:carrots	age=0
2257	minecraft:carrots	age=1
2258	minecraft:carrots	age=2
2259	minecraft:carrots	age=3
2260	minecraft:carrots	age=4
2261	minecraft:carrots	age=5
2262	minecraft:carrots	age=6
2263	minecraft:carrots	age=7
2272	minecraft:potatoes	age=0
2273	minecraft:potatoes	age=1
2274	minecraft:potatoes	age=2
2275	minecraft:potatoes	age=3
2276	minecraft:potatoes	age=4
2277	minecraft:potatoes	age=5
2278	minecraft:potatoes	age=6
2279	minecraft:potatoes	age=7
2288	minecraft:oak_button	face=ceiling;facing=north;powered=false
2289	minecraft:oak_button	face=wall;facing=east;powered=false
2290	minecraft:oak_button	face=wall;facing=west;powered=false
2291	minecraft:oak_button	face=wall;facing=south;powered=false
2292	minecraft:oak_button	face=wall;facing=north;powered=false
2293	minecraft:oak_button	face=floor;facing=north;powered=false
2296	minecraft:oak_button	face=ceiling;facing=north;powered=true
2297	minecraft:oak_button	face=wall;facing=east;powered=true
2298	minecraft:oak_button	face=wall;facing=west;powered=true
2299	minecraft:oak_button	face=wall;facing=south;powered=true
2300	minecraft:oak_button	face=wall;facing=north;powered=true
2301	minecraft:oak_button	face=floor;facing=north;powered=true
2304	%%FILTER_ME%%	facing=down;nodrop=false
2305	%%FILTER_ME%%	facing=up;nodrop=false
2306	%%FILTER_ME%%	facing=north;nodrop=false
2307	%%FILTER_ME%%	facing=south;nodrop=false
2308	%%FILTER_ME%%	facing=west;nodrop=false
2309	%%FILTER_ME%%	facing=east;nodrop=false
2312	%%FILTER_ME%%	facing=down;nodrop=true
2313	%%FILTER_ME%%	facing=up;nodrop=true
2314	%%FILTER_ME%%	facing=north;nodrop=true
2315	%%FILTER_ME%%	facing=south;nodrop=true
2316	%%FILTER_ME%%	facing=west;nodrop=true
2317	%%FILTER_ME%%	facing=east;nodrop=true
2320	minecraft:anvil	facing=south
2321	minecraft:anvil	facing=west
2322	minecraft:anvil	facing=north
2323	minecraft:anvil	facing=east
2324	minecraft:chipped_anvil	facing=south
2325	minecraft:chipped_anvil	facing=west
2326	minecraft:chipped_anvil	facing=north
2327	minecraft:chipped_anvil	facing=east
2328	minecraft:damaged_anvil	facing=south
2329	minecraft:damaged_anvil	facing=west
2330	minecraft:damaged_anvil	facing=north
2331	minecraft:damaged_anvil	facing=east
2338	minecraft:trapped_chest	facing=north;type=single
2339	minecraft:trapped_chest	facing=south;type=single
2340	minecraft:trapped_chest	facing=west;type=single
2341	minecraft:trapped_chest	facing=east;type=single
2352	minecraft:light_weighted_pressure_plate	power=0
2353	minecraft:light_weighted_pressure_plate	power=1
2354	minecraft:light_weighted_pressure_plate	power=2
2355	minecraft:light_weighted_pressure_plate	power=3
2356	minecraft:light_weighted_pressure_plate	power=4
2357	minecraft:light_weighted_pressure_plate	power=5
2358	minecraft:light_weighted_pressure_plate	power=6
2359	minecraft:light_weighted_pressure_plate	power=7
2360	minecraft:light_weighted_pressure_plate	power=8
2361	minecraft:light_weighted_pressure_plate	power=9
2362	minecraft:light_weighted_pressure_plate	power=10
2363	minecraft:light_weighted_pressure_plate	power=11
2364	minecraft:light_weighted_pressure_plate	power=12
2365	minecraft:light_weighted_pressure_plate	power=13
2366	minecraft:light_weighted_pressure_plate	power=14
2367	minecraft:light_weighted_pressure_plate	power=15
2368	minecraft:heavy_weighted_pressure_plate	power=0
2369	minecraft:heavy_weighted_pressure_plate	power=1
2370	minecraft:heavy_weighted_pressure_plate	power=2
2371	minecraft:heavy_weighted_pressure_plate	power=3
2372	minecraft:heavy_weighted_pressure_plate	power=4
2373	minecraft:heavy_weighted_pressure_plate	power=5
2374	minecraft:heavy_weighted_pressure_plate	power=6
2375	minecraft:heavy_weighted_pressure_plate	power=7
2376	minecraft:heavy_weighted_pressure_plate	power=8
2377	minecraft:heavy_weighted_pressure_plate	power=9
2378	minecraft:heavy_weighted_pressure_plate	power=10
2379	minecraft:heavy_weighted_pressure_plate	power=11
2380	minecraft:heavy_weighted_pressure_plate	power=12
2381	minecraft:heavy_weighted_pressure_plate	power=13
2382	minecraft:heavy_weighted_pressure_plate	power=14
2383	minecraft:heavy_weighted_pressure_plate	power=15
2384	minecraft:comparator	facing=south;mode=compare;powered=false
2385	minecraft:comparator	facing=west;mode=compare;powered=false
2386	minecraft:comparator	facing=north;mode=compare;powered=false
2387	minecraft:comparator	facing=east;mode=compare;powered=false
2388	minecraft:comparator	facing=south;mode=subtract;powered=false
2389	minecraft:comparator	facing=west;mode=subtract;powered=false
2390	minecraft:comparator	facing=north;mode=subtract;powered=false
2391	minecraft:comparator	facing=east;mode=subtract;powered=false
2392	minecraft:comparator	facing=south;mode=compare;powered=true
2393	minecraft:comparator	facing=west;mode=compare;powered=true
2394	minecraft:comparator	facing=north;mode=compare;powered=true
2395	minecraft:comparator	facing=east;mode=compare;powered=true
2396	minecraft:comparator	facing=south;mode=subtract;powered=true
2397	minecraft:comparator	facing=west;mode=subtract;powered=true
2398	minecraft:comparator	facing=north;mode=subtract;powered=true
2399	minecraft:comparator	facing=east;mode=subtract;powered=true
2400	minecraft:comparator	facing=south;mode=compare;powered=false
2401	minecraft:comparator	facing=west;mode=compare;powered=false
2402	minecraft:comparator	facing=north;mode=compare;powered=false
2403	minecraft:comparator	facing=east;mode=compare;powered=false
2404	minecraft:comparator	facing=south;mode=subtract;powered=false
2405	minecraft:comparator	facing=west;mode=subtract;powered=false
2406	minecraft:comparator	facing=north;mode=subtract;powered=false
2407	minecraft:comparator	facing=east;mode=subtract;powered=false
2408	minecraft:comparator	facing=south;mode=compare;powered=true
2409	minecraft:comparator	facing=west;mode=compare;powered=true
2410	minecraft:comparator	facing=north;mode=compare;powered=true
2411	minecraft:comparator	facing=east;mode=compare;powered=true
2412	minecraft:comparator	facing=south;mode=subtract;powered=true
2413	minecraft:comparator	facing=west;mode=subtract;powered=true
2414	minecraft:comparator	facing=north;mode=subtract;powered=true
2415	minecraft:comparator	facing=east;mode=subtract;powered=true
2416	minecraft:daylight_detector	inverted=false;power=0
2417	minecraft:daylight_detector	inverted=false;power=1
2418	minecraft:daylight_detector	inverted=false;power=2
2419	minecraft:daylight_detector	inverted=false;power=3
2420	minecraft:daylight_detector	inverted=false;power=4
2421	minecraft:daylight_detector	inverted=false;power=5
2422	minecraft:daylight_detector	inverted=false;power=6
2423	minecraft:daylight_detector	inverted=false;power=7
2424	minecraft:daylight_detector	inverted=false;power=8
2425	minecraft:daylight_detector	inverted=false;power=9
2426	minecraft:daylight_detector	inverted=false;power=10
2427	minecraft:daylight_detector	inverted=false;power=11
2428	minecraft:daylight_detector	inverted=false;power=12
2429	minecraft:daylight_detector	inverted=false;power=13
2430	minecraft:daylight_detector	inverted=false;power=14
2431	minecraft:daylight_detector	inverted=false;power=15
2432	minecraft:redstone_block	
2448	minecraft:nether_quartz_ore	
2464	minecraft:hopper	enabled=true;facing=down
2466	minecraft:hopper	enabled=true;facing=north
2467	minecraft:hopper	enabled=true;facing=south
2468	minecraft:hopper	enabled=true;facing=west
2469	minecraft:hopper	enabled=true;facing=east
2472	minecraft:hopper	enabled=false;facing=down
2474	minecraft:hopper	enabled=false;facing=north
2475	minecraft:hopper	enabled=false;facing=south
2476	minecraft:hopper	enabled=false;facing=west
2477	minecraft:hopper	enabled=false;facing=east
2480	minecraft:quartz_block	
2481	minecraft:chiseled_quartz_block	
2482	minecraft:quartz_pillar	axis=y
2483	minecraft:quartz_pillar	axis=x
2484	minecraft:quartz_pillar	axis=z
2496	minecraft:quartz_stairs	facing=east;half=bottom;shape=straight
2497	minecraft:quartz_stairs	facing=west;half=bottom;shape=straight
2498	minecraft:quartz_stairs	facing=south;half=bottom;shape=straight
2499	minecraft:quartz_stairs	facing=north;half=bottom;shape=straight
2500	minecraft:quartz_stairs	facing=east;half=top;shape=straight
2501	minecraft:quartz_stairs	facing=west;half=top;shape=straight
2502	minecraft:quartz_stairs	facing=south;half=top;shape=straight
2503	minecraft:quartz_stairs	facing=north;half=top;shape=straight
2512	minecraft:activator_rail	powered=false;shape=north_south
2513	minecraft:activator_rail	powered=false;shape=east_west
2514	minecraft:activator_rail	powered=false;shape=ascending_east
2515	minecraft:activator_rail	powered=false;shape=ascending_west
2516	minecraft:activator_rail	powered=false;shape=ascending_north
2517	minecraft:activator_rail	powered=false;shape=ascending_south
2520	minecraft:activator_rail	powered=true;shape=north_south
2521	minecraft:activator_rail	powered=true;shape=east_west
2522	minecraft:activator_rail	powered=true;shape=ascending_east
2523	minecraft:activator_rail	powered=true;shape=ascending_west
2524	minecraft:activator_rail	powered=true;shape=ascending_north
2525	minecraft:activator_rail	powered=true;shape=ascending_south
2528	minecraft:dropper	facing=down;triggered=false
2529	minecraft:dropper	facing=up;triggered=false
2530	minecraft:dropper	facing=north;triggered=false
2531	minecraft:dropper	facing=south;triggered=false
2532	minecraft:dropper	facing=west;triggered=false
2533	minecraft:dropper	facing=east;triggered=false
2536	minecraft:dropper	facing=down;triggered=true
2537	minecraft:dropper	facing=up;triggered=true
2538	minecraft:dropper	facing=north;triggered=true
2539	minecraft:dropper	facing=south;triggered=true
2540	minecraft:dropper	facing=west;triggered=true
2541	minecraft:dropper	facing=east;triggered=true
2544	minecraft:white_terracotta	
2545	minecraft:orange_terracotta	
2546	minecraft:magenta_terracotta	
2547	minecraft:light_blue_terracotta	
2548	minecraft:yellow_terracotta	
2549	minecraft:lime_terracotta	
2550	minecraft:pink_terracotta	
2551	minecraft:gray_terracotta	
2552	minecraft:light_gray_terracotta	
2553	minecraft:cyan_terracotta	
2554	minecraft:purple_terracotta	
2555	minecraft:blue_terracotta	
2556	minecraft:brown_terracotta	
2557	minecraft:green_terracotta	
2558	minecraft:red_terracotta	
2559	minecraft:black_terracotta	
2560	minecraft:white_stained_glass_pane	east=false;north=false;south=false;west=false
2561	minecraft:orange_stained_glass_pane	east=false;north=false;south=false;west=false
2562	minecraft:magenta_stained_glass_pane	east=false;north=false;south=false;west=false
2563	minecraft:light_blue_stained_glass_pane	east=false;north=false;south=false;west=false
2564	minecraft:yellow_stained_glass_pane	east=false;north=false;south=false;west=false
2565	minecraft:lime_stained_glass_pane	east=false;north=false;south=false;west=false
2566	minecraft:pink_stained_glass_pane	east=false;north=false;south=false;west=false
2567	minecraft:gray_stained_glass_pane	east=false;north=false;south=false;west=false
2568	minecraft:light_gray_stained_glass_pane	east=false;north=false;south=false;west=false
2569	minecraft:cyan_stained_glass_pane	east=false;north=false;south=false;west=false
2570	minecraft:purple_stained_glass_pane	east=false;north=false;south=false;west=false
2571	minecraft:blue_stained_glass_pane	east=false;north=false;south=false;west=false
2572	minecraft:brown_stained_glass_pane	east=false;north=false;south=false;west=false
2573	minecraft:green_stained_glass_pane	east=false;north=false;south=false;west=false
2574	minecraft:red_stained_glass_pane	east=false;north=false;south=false;west=false
2575	minecraft:black_stained_glass_pane	east=false;north=false;south=false;west=false
2576	minecraft:acacia_leaves	check_decay=false;decayable=true
2577	minecraft:dark_oak_leaves	check_decay=false;decayable=true
2580	minecraft:acacia_leaves	check_decay=false;decayable=false
2581	minecraft:dark_oak_leaves	check_decay=false;decayable=false
2584	minecraft:acacia_leaves	check_decay=true;decayable=true
2585	minecraft:dark_oak_leaves	check_decay=true;decayable=true
2588	minecraft:acacia_leaves	check_decay=true;decayable=false
2589	minecraft:dark_oak_leaves	check_decay=true;decayable=false
2592	minecraft:acacia_log	axis=y
2593	minecraft:dark_oak_log	axis=y
2596	minecraft:acacia_log	axis=x
2597	minecraft:dark_oak_log	axis=x
2600	minecraft:acacia_log	axis=z
2601	minecraft:dark_oak_log	axis=z
2604	minecraft:acacia_bark	
2605	minecraft:dark_oak_bark	
2608	minecraft:acacia_stairs	facing=east;half=bottom;shape=straight
2609	minecraft:acacia_stairs	facing=west;half=bottom;shape=straight
2610	minecraft:acacia_stairs	facing=south;half=bottom;shape=straight
2611	minecraft:acacia_stairs	facing=north;half=bottom;shape=straight
2612	minecraft:acacia_stairs	facing=east;half=top;shape=straight
2613	minecraft:acacia_stairs	facing=west;half=top;shape=straight
2614	minecraft:acacia_stairs	facing=south;half=top;shape=straight
2615	minecraft:acacia_stairs	facing=north;half=top;shape=straight
2624	minecraft:dark_oak_stairs	facing=east;half=bottom;shape=straight
2625	minecraft:dark_oak_stairs	facing=west;half=bottom;shape=straight
2626	minecraft:dark_oak_stairs	facing=south;half=bottom;shape=straight
2627	minecraft:dark_oak_stairs	facing=north;half=bottom;shape=straight
2628	minecraft:dark_oak_stairs	facing=east;half=top;shape=straight
2629	minecraft:dark_oak_stairs	facing=west;half=top;shape=straight
2630	minecraft:dark_oak_stairs	facing=south;half=top;shape=straight
2631	minecraft:dark_oak_stairs	facing=north;half=top;shape=straight
2640	minecraft:slime_block	
2656	minecraft:barrier	
2672	minecraft:iron_trapdoor	facing=north;half=bottom;open=false
2673	minecraft:iron_trapdoor	facing=south;half=bottom;open=false
2674	minecraft:iron_trapdoor	facing=west;half=bottom;open=false
2675	minecraft:iron_trapdoor	facing=east;half=bottom;open=false
2676	minecraft:iron_trapdoor	facing=north;half=bottom;open=true
2677	minecraft:iron_trapdoor	facing=south;half=bottom;open=true
2678	minecraft:iron_trapdoor	facing=west;half=bottom;open=true
2679	minecraft:iron_trapdoor	facing=east;half=bottom;open=true
2680	minecraft:iron_trapdoor	facing=north;half=top;open=false
2681	minecraft:iron_trapdoor	facing=south;half=top;open=false
2682	minecraft:iron_trapdoor	facing=west;half=top;open=false
2683	minecraft:iron_trapdoor	facing=east;half=top;open=false
2684	minecraft:iron_trapdoor	facing=north;half=top;open=true
2685	minecraft:iron_trapdoor	facing=south;half=top;open=true
2686	minecraft:iron_trapdoor	facing=west;half=top;open=true
2687	minecraft:iron_trapdoor	facing=east;half=top;open=true
2688	minecraft:prismarine	
2689	minecraft:prismarine_bricks	
2690	minecraft:dark_prismarine	
2704	minecraft:sea_lantern	
2720	minecraft:hay_block	axis=y
2724	minecraft:hay_block	axis=x
2728	minecraft:hay_block	axis=z
2736	minecraft:white_carpet	
2737	minecraft:orange_carpet	
2738	minecraft:magenta_carpet	
2739	minecraft:light_blue_carpet	
2740	minecraft:yellow_carpet	
2741	minecraft:lime_carpet	
2742	minecraft:pink_carpet	
2743	minecraft:gray_carpet	
2744	minecraft:light_gray_carpet	
2745	minecraft:cyan_carpet	
2746	minecraft:purple_carpet	
2747	minecraft:blue_carpet	
2748	minecraft:brown_carpet	
2749	minecraft:green_carpet	
2750	minecraft:red_carpet	
2751	minecraft:black_carpet	
2752	minecraft:terracotta	
2768	minecraft:coal_block	
2784	minecraft:packed_ice	
2800	minecraft:sunflower	half=lower
2801	minecraft:lilac	half=lower
2802	minecraft:tall_grass	half=lower
2803	minecraft:large_fern	half=lower
2804	minecraft:rose_bush	half=lower
2805	minecraft:peony	half=lower
2808	minecraft:peony	half=upper
2809	minecraft:peony	half=upper
2810	minecraft:peony	half=upper
2811	minecraft:peony	half=upper
2816	minecraft:white_banner	rotation=0
2817	minecraft:white_banner	rotation=1
2818	minecraft:white_banner	rotation=2
2819	minecraft:white_banner	rotation=3
2820	minecraft:white_banner	rotation=4
2821	minecraft:white_banner	rotation=5
2822	minecraft:white_banner	rotation=6
2823	minecraft:white_banner	rotation=7
2824	minecraft:white_banner	rotation=8
2825	minecraft:white_banner	rotation=9
2826	minecraft:white_banner	rotation=10
2827	minecraft:white_banner	rotation=11
2828	minecraft:white_banner	rotation=12
2829	minecraft:white_banner	rotation=13
2830	minecraft:white_banner	rotation=14
2831	minecraft:white_banner	rotation=15
2834	minecraft:white_wall_banner	facing=north
2835	minecraft:white_wall_banner	facing=south
2836	minecraft:white_wall_banner	facing=west
2837	minecraft:white_wall_banner	facing=east
2848	minecraft:daylight_detector	inverted=true;power=0
2849	minecraft:daylight_detector	inverted=true;power=1
2850	minecraft:daylight_detector	inverted=true;power=2
2851	minecraft:daylight_detector	inverted=true;power=3
2852	minecraft:daylight_detector	inverted=true;power=4
2853	minecraft:daylight_detector	inverted=true;power=5
2854	minecraft:daylight_detector	inverted=true;power=6
2855	minecraft:daylight_detector	inverted=true;power=7
2856	minecraft:daylight_detector	inverted=true;power=8
2857	minecraft:daylight_detector	inverted=true;power=9
2858	minecraft:daylight_detector	inverted=true;power=10
2859	minecraft:daylight_detector	inverted=true;power=11
2860	minecraft:daylight_detector	inverted=true;power=12
2861	minecraft:daylight_detector	inverted=true;power=13
2862	minecraft:daylight_detector	inverted=true;power=14
2863	minecraft:daylight_detector	inverted=true;power=15
2864	minecraft:red_sandstone	
2865	minecraft:chiseled_red_sandstone	
2866	minecraft:cut_red_sandstone	
2880	minecraft:red_sandstone_stairs	facing=east;half=bottom;shape=straight
2881	minecraft:red_sandstone_stairs	facing=west;half=bottom;shape=straight
2882	minecraft:red_sandstone_stairs	facing=south;half=bottom;shape=straight
2883	minecraft:red_sandstone_stairs	facing=north;half=bottom;shape=straight
2884	minecraft:red_sandstone_stairs	facing=east;half=top;shape=straight
2885	minecraft:red_sandstone_stairs	facing=west;half=top;shape=straight
2886	minecraft:red_sandstone_stairs	facing=south;half=top;shape=straight
2887	minecraft:red_sandstone_stairs	facing=north;half=top;shape=straight
2896	minecraft:red_sandstone_slab	type=double
2904	minecraft:smooth_red_sandstone	
2912	minecraft:red_sandstone_slab	type=bottom
2920	minecraft:red_sandstone_slab	type=top
2928	minecraft:spruce_fence_gate	facing=south;in_wall=false;open=false;powered=false
2929	minecraft:spruce_fence_gate	facing=west;in_wall=false;open=false;powered=false
2930	minecraft:spruce_fence_gate	facing=north;in_wall=false;open=false;powered=false
2931	minecraft:spruce_fence_gate	facing=east;in_wall=false;open=false;powered=false
2932	minecraft:spruce_fence_gate	facing=south;in_wall=false;open=true;powered=false
2933	minecraft:spruce_fence_gate	facing=west;in_wall=false;open=true;powered=false
2934	minecraft:spruce_fence_gate	facing=north;in_wall=false;open=true;powered=false
2935	minecraft:spruce_fence_gate	facing=east;in_wall=false;open=true;powered=false
2936	minecraft:spruce_fence_gate	facing=south;in_wall=false;open=false;powered=true
2937	minecraft:spruce_fence_gate	facing=west;in_wall=false;open=false;powered=true
2938	minecraft:spruce_fence_gate	facing=north;in_wall=false;open=false;powered=true
2939	minecraft:spruce_fence_gate	facing=east;in_wall=false;open=false;powered=true
2940	minecraft:spruce_fence_gate	facing=south;in_wall=false;open=true;powered=true
2941	minecraft:spruce_fence_gate	facing=west;in_wall=false;open=true;powered=true
2942	minecraft:spruce_fence_gate	facing=north;in_wall=false;open=true;powered=true
2943	minecraft:spruce_fence_gate	facing=east;in_wall=false;open=true;powered=true
2944	minecraft:birch_fence_gate	facing=south;in_wall=false;open=false;powered=false
2945	minecraft:birch_fence_gate	facing=west;in_wall=false;open=false;powered=false
2946	minecraft:birch_fence_gate	facing=north;in_wall=false;open=false;powered=false
2947	minecraft:birch_fence_gate	facing=east;in_wall=false;open=false;powered=false
2948	minecraft:birch_fence_gate	facing=south;in_wall=false;open=true;powered=false
2949	minecraft:birch_fence_gate	facing=west;in_wall=false;open=true;powered=false
2950	minecraft:birch_fence_gate	facing=north;in_wall=false;open=true;powered=false
2951	minecraft:birch_fence_gate	facing=east;in_wall=false;open=true;powered=false
2952	minecraft:birch_fence_gate	facing=south;in_wall=false;open=false;powered=true
2953	minecraft:birch_fence_gate	facing=west;in_wall=false;open=false;powered=true
2954	minecraft:birch_fence_gate	facing=north;in_wall=false;open=false;powered=true
2955	minecraft:birch_fence_gate	facing=east;in_wall=false;open=false;powered=true
2956	minecraft:birch_fence_gate	facing=south;in_wall=false;open=true;powered=true
2957	minecraft:birch_fence_gate	facing=west;in_wall=false;open=true;powered=true
2958	minecraft:birch_fence_gate	facing=north;in_wall=false;open=true;powered=true
2959	minecraft:birch_fence_gate	facing=east;in_wall=false;open=true;powered=true
2960	minecraft:jungle_fence_gate	facing=south;in_wall=false;open=false;powered=false
2961	minecraft:jungle_fence_gate	facing=west;in_wall=false;open=false;powered=false
2962	minecraft:jungle_fence_gate	facing=north;in_wall=false;open=false;powered=false
2963	minecraft:jungle_fence_gate	facing=east;in_wall=false;open=false;powered=false
2964	minecraft:jungle_fence_gate	facing=south;in_wall=false;open=true;powered=false
2965	minecraft:jungle_fence_gate	facing=west;in_wall=false;open=true;powered=false
2966	minecraft:jungle_fence_gate	facing=north;in_wall=false;open=true;powered=false
2967	minecraft:jungle_fence_gate	facing=east;in_wall=false;open=true;powered=false
2968	minecraft:jungle_fence_gate	facing=south;in_wall=false;open=false;powered=true
2969	minecraft:jungle_fence_gate	facing=west;in_wall=false;open=false;powered=true
2970	minecraft:jungle_fence_gate	facing=north;in_wall=false;open=false;powered=true
2971	minecraft:jungle_fence_gate	facing=east;in_wall=false;open=false;powered=true
2972	minecraft:jungle_fence_gate	facing=south;in_wall=false;open=true;powered=true
2973	minecraft:jungle_fence_gate	facing=west;in_wall=false;open=true;powered=true
2974	minecraft:jungle_fence_gate	facing=north;in_wall=false;open=true;powered=true
2975	minecraft:jungle_fence_gate	facing=east;in_wall=false;open=true;powered=true
2976	minecraft:dark_oak_fence_gate	facing=south;in_wall=false;open=false;powered=false
2977	minecraft:dark_oak_fence_gate	facing=west;in_wall=false;open=false;powered=false
2978	minecraft:dark_oak_fence_gate	facing=north;in_wall=false;open=false;powered=false
2979	minecraft:dark_oak_fence_gate	facing=east;in_wall=false;open=false;powered=false
2980	minecraft:dark_oak_fence_gate	facing=south;in_wall=false;open=true;powered=false
2981	minecraft:dark_oak_fence_gate	facing=west;in_wall=false;open=true;powered=false
2982	minecraft:dark_oak_fence_gate	facing=north;in_wall=false;open=true;powered=false
2983	minecraft:dark_oak_fence_gate	facing=east;in_wall=false;open=true;powered=false
2984	minecraft:dark_oak_fence_gate	facing=south;in_wall=false;open=false;powered=true
2985	minecraft:dark_oak_fence_gate	facing=west;in_wall=false;open=false;powered=true
2986	minecraft:dark_oak_fence_gate	facing=north;in_wall=false;open=false;powered=true
2987	minecraft:dark_oak_fence_gate	facing=east;in_wall=false;open=false;powered=true
2988	minecraft:dark_oak_fence_gate	facing=south;in_wall=false;open=true;powered=true
2989	minecraft:dark_oak_fence_gate	facing=west;in_wall=false;open=true;powered=true
2990	minecraft:dark_oak_fence_gate	facing=north;in_wall=false;open=true;powered=true
2991	minecraft:dark_oak_fence_gate	facing=east;in_wall=false;open=true;powered=true
2992	minecraft:acacia_fence_gate	facing=south;in_wall=false;open=false;powered=false
2993	minecraft:acacia_fence_gate	facing=west;in_wall=false;open=false;powered=false
2994	minecraft:acacia_fence_gate	facing=north;in_wall=false;open=false;powered=false
2995	minecraft:acacia_fence_gate	facing=east;in_wall=false;open=false;powered=false
2996	minecraft:acacia_fence_gate	facing=south;in_wall=false;open=true;powered=false
2997	minecraft:acacia_fence_gate	facing=west;in_wall=false;open=true;powered=false
2998	minecraft:acacia_fence_gate	facing=north;in_wall=false;open=true;powered=false
2999	minecraft:acacia_fence_gate	facing=east;in_wall=false;open=true;powered=false
3000	minecraft:acacia_fence_gate	facing=south;in_wall=false;open=false;powered=true
3001	minecraft:acacia_fence_gate	facing=west;in_wall=false;open=false;powered=true
3002	minecraft:acacia_fence_gate	facing=north;in_wall=false;open=false;powered=true
3003	minecraft:acacia_fence_gate	facing=east;in_wall=false;open=false;powered=true
3004	minecraft:acacia_fence_gate	facing=south;in_wall=false;open=true;powered=true
3005	minecraft:acacia_fence_gate	facing=west;in_wall=false;open=true;powered=true
3006	minecraft:acacia_fence_gate	facing=north;in_wall=false;open=true;powered=true
3007	minecraft:acacia_fence_gate	facing=east;in_wall=false;open=true;powered=true
3008	minecraft:spruce_fence	east=false;north=false;south=false;west=false
3024	minecraft:birch_fence	east=false;north=false;south=false;west=false
3040	minecraft:jungle_fence	east=false;north=false;south=false;west=false
3056	minecraft:dark_oak_fence	east=false;north=false;south=false;west=false
3072	minecraft:acacia_fence	east=false;north=false;south=false;west=false
3088	minecraft:spruce_door	facing=east;half=lower;hinge=right;open=false;powered=false
3089	minecraft:spruce_door	facing=south;half=lower;hinge=right;open=false;powered=false
3090	minecraft:spruce_door	facing=west;half=lower;hinge=right;open=false;powered=false
3091	minecraft:spruce_door	facing=north;half=lower;hinge=right;open=false;powered=false
3092	minecraft:spruce_door	facing=east;half=lower;hinge=right;open=true;powered=false
3093	minecraft:spruce_door	facing=south;half=lower;hinge=right;open=true;powered=false
3094	minecraft:spruce_door	facing=west;half=lower;hinge=right;open=true;powered=false
3095	minecraft:spruce_door	facing=north;half=lower;hinge=right;open=true;powered=false
3096	minecraft:spruce_door	facing=east;half=upper;hinge=left;open=false;powered=false
3097	minecraft:spruce_door	facing=east;half=upper;hinge=right;open=false;powered=false
3098	minecraft:spruce_door	facing=east;half=upper;hinge=left;open=false;powered=true
3099	minecraft:spruce_door	facing=east;half=upper;hinge=right;open=false;powered=true
3104	minecraft:birch_door	facing=east;half=lower;hinge=right;open=false;powered=false
3105	minecraft:birch_door	facing=south;half=lower;hinge=right;open=false;powered=false
3106	minecraft:birch_door	facing=west;half=lower;hinge=right;open=false;powered=false
3107	minecraft:birch_door	facing=north;half=lower;hinge=right;open=false;powered=false
3108	minecraft:birch_door	facing=east;half=lower;hinge=right;open=true;powered=false
3109	minecraft:birch_door	facing=south;half=lower;hinge=right;open=true;powered=false
3110	minecraft:birch_door	facing=west;half=lower;hinge=right;open=true;powered=false
3111	minecraft:birch_door	facing=north;half=lower;hinge=right;open=true;powered=false
3112	minecraft:birch_door	facing=east;half=upper;hinge=left;open=false;powered=false
3113	minecraft:birch_door	facing=east;half=upper;hinge=right;open=false;powered=false
3114	minecraft:birch_door	facing=east;half=upper;hinge=left;open=false;powered=true
3115	minecraft:birch_door	facing=east;half=upper;hinge=right;open=false;powered=true
3120	minecraft:jungle_door	facing=east;half=lower;hinge=right;open=false;powered=false
3121	minecraft:jungle_door	facing=south;half=lower;hinge=right;open=false;powered=false
3122	minecraft:jungle_door	facing=west;half=lower;hinge=right;open=false;powered=false
3123	minecraft:jungle_door	facing=north;half=lower;hinge=right;open=false;powered=false
3124	minecraft:jungle_door	facing=east;half=lower;hinge=right;open=true;powered=false
3125	minecraft:jungle_door	facing=south;half=lower;hinge=right;open=true;powered=false
3126	minecraft:jungle_door	facing=west;half=lower;hinge=right;open=true;powered=false
3127	minecraft:jungle_door	facing=north;half=lower;hinge=right;open=true;powered=false
3128	minecraft:jungle_door	facing=east;half=upper;hinge=left;open=false;powered=false
3129	minecraft:jungle_door	facing=east;half=upper;hinge=right;open=false;powered=false
3130	minecraft:jungle_door	facing=east;half=upper;hinge=left;open=false;powered=true
3131	minecraft:jungle_door	facing=east;half=upper;hinge=right;open=false;powered=true
3136	minecraft:acacia_door	facing=east;half=lower;hinge=right;open=false;powered=false
3137	minecraft:acacia_door	facing=south;half=lower;hinge=right;open=false;powered=false
3138	minecraft:acacia_door	facing=west;half=lower;hinge=right;open=false;powered=false
3139	minecraft:acacia_door	facing=north;half=lower;hinge=right;open=false;powered=false
3140	minecraft:acacia_door	facing=east;half=lower;hinge=right;open=true;powered=false
3141	minecraft:acacia_door	facing=south;half=lower;hinge=right;open=true;powered=false
3142	minecraft:acacia_door	facing=west;half=lower;hinge=right;open=true;powered=false
3143	minecraft:acacia_door	facing=north;half=lower;hinge=right;open=true;powered=false
3144	minecraft:acacia_door	facing=east;half=upper;hinge=left;open=false;powered=false
3145	minecraft:acacia_door	facing=east;half=upper;hinge=right;open=false;powered=false
3146	minecraft:acacia_door	facing=east;half=upper;hinge=left;open=false;powered=true
3147	minecraft:acacia_door	facing=east;half=upper;hinge=right;open=false;powered=true
3152	minecraft:dark_oak_door	facing=east;half=lower;hinge=right;open=false;powered=false
3153	minecraft:dark_oak_door	facing=south;half=lower;hinge=right;open=false;powered=false
3154	minecraft:dark_oak_door	facing=west;half=lower;hinge=right;open=false;powered=false
3155	minecraft:dark_oak_door	facing=north;half=lower;hinge=right;open=false;powered=false
3156	minecraft:dark_oak_door	facing=east;half=lower;hinge=right;open=true;powered=false
3157	minecraft:dark_oak_door	facing=south;half=lower;hinge=right;open=true;powered=false
3158	minecraft:dark_oak_door	facing=west;half=lower;hinge=right;open=true;powered=false
3159	minecraft:dark_oak_door	facing=north;half=lower;hinge=right;open=true;powered=false
3160	minecraft:dark_oak_door	facing=east;half=upper;hinge=left;open=false;powered=false
3161	minecraft:dark_oak_door	facing=east;half=upper;hinge=right;open=false;powered=false
3162	minecraft:dark_oak_door	facing=east;half=upper;hinge=left;open=false;powered=true
3163	minecraft:dark_oak_door	facing=east;half=upper;hinge=right;open=false;powered=true
3168	minecraft:end_rod	facing=down
3169	minecraft:end_rod	facing=up
3170	minecraft:end_rod	facing=north
3171	minecraft:end_rod	facing=south
3172	minecraft:end_rod	facing=west
3173	minecraft:end_rod	facing=east
3184	minecraft:chorus_plant	down=false;east=false;north=false;south=false;up=false;west=false
3200	minecraft:chorus_flower	age=0
3201	minecraft:chorus_flower	age=1
3202	minecraft:chorus_flower	age=2
3203	minecraft:chorus_flower	age=3
3204	minecraft:chorus_flower	age=4
3205	minecraft:chorus_flower	age=5
3216	minecraft:purpur_block	
3232	minecraft:purpur_pillar	axis=y
3236	minecraft:purpur_pillar	axis=x
3240	minecraft:purpur_pillar	axis=z
3248	minecraft:purpur_stairs	facing=east;half=bottom;shape=straight
3249	minecraft:purpur_stairs	facing=west;half=bottom;shape=straight
3250	minecraft:purpur_stairs	facing=south;half=bottom;shape=straight
3251	minecraft:purpur_stairs	facing=north;half=bottom;shape=straight
3252	minecraft:purpur_stairs	facing=east;half=top;shape=straight
3253	minecraft:purpur_stairs	facing=west;half=top;shape=straight
3254	minecraft:purpur_stairs	facing=south;half=top;shape=straight
3255	minecraft:purpur_stairs	facing=north;half=top;shape=straight
3264	minecraft:purpur_slab	type=double
3280	minecraft:purpur_slab	type=bottom
3288	minecraft:purpur_slab	type=top
3296	minecraft:end_stone_bricks	
3312	minecraft:beetroots	age=0
3313	minecraft:beetroots	age=1
3314	minecraft:beetroots	age=2
3315	minecraft:beetroots	age=3
3328	minecraft:grass_path	
3344	minecraft:end_gateway	
3360	minecraft:repeating_command_block	conditional=false;facing=down
3361	minecraft:repeating_command_block	conditional=false;facing=up
3362	minecraft:repeating_command_block	conditional=false;facing=north
3363	minecraft:repeating_command_block	conditional=false;facing=south
3364	minecraft:repeating_command_block	conditional=false;facing=west
3365	minecraft:repeating_command_block	conditional=false;facing=east
3368	minecraft:repeating_command_block	conditional=true;facing=down
3369	minecraft:repeating_command_block	conditional=true;facing=up
3370	minecraft:repeating_command_block	conditional=true;facing=north
3371	minecraft:repeating_command_block	conditional=true;facing=south
3372	minecraft:repeating_command_block	conditional=true;facing=west
3373	minecraft:repeating_command_block	conditional=true;facing=east
3376	minecraft:chain_command_block	conditional=false;facing=down
3377	minecraft:chain_command_block	conditional=false;facing=up
3378	minecraft:chain_command_block	conditional=false;facing=north
3379	minecraft:chain_command_block	conditional=false;facing=south
3380	minecraft:chain_command_block	conditional=false;facing=west
3381	minecraft:chain_command_block	conditional=false;facing=east
3384	minecraft:chain_command_block	conditional=true;facing=down
3385	minecraft:chain_command_block	conditional=true;facing=up
3386	minecraft:chain_command_block	conditional=true;facing=north
3387	minecraft:chain_command_block	conditional=true;facing=south
3388	minecraft:chain_command_block	conditional=true;facing=west
3389	minecraft:chain_command_block	conditional=true;facing=east
3392	minecraft:frosted_ice	age=0
3393	minecraft:frosted_ice	age=1
3394	minecraft:frosted_ice	age=2
3395	minecraft:frosted_ice	age=3
3408	minecraft:magma_block	
3424	minecraft:nether_wart_block	
3440	minecraft:red_nether_bricks	
3456	minecraft:bone_block	axis=y
3460	minecraft:bone_block	axis=x
3464	minecraft:bone_block	axis=z
3472	minecraft:structure_void	
3488	minecraft:observer	facing=down;powered=false
3489	minecraft:observer	facing=up;powered=false
3490	minecraft:observer	facing=north;powered=false
3491	minecraft:observer	facing=south;powered=false
3492	minecraft:observer	facing=west;powered=false
3493	minecraft:observer	facing=east;powered=false
3496	minecraft:observer	facing=down;powered=true
3497	minecraft:observer	facing=up;powered=true
3498	minecraft:observer	facing=north;powered=true
3499	minecraft:observer	facing=south;powered=true
3500	minecraft:observer	facing=west;powered=true
3501	minecraft:observer	facing=east;powered=true
3504	minecraft:white_shulker_box	facing=down
3505	minecraft:white_shulker_box	facing=up
3506	minecraft:white_shulker_box	facing=north
3507	minecraft:white_shulker_box	facing=south
3508	minecraft:white_shulker_box	facing=west
3509	minecraft:white_shulker_box	facing=east
3520	minecraft:orange_shulker_box	facing=down
3521	minecraft:orange_shulker_box	facing=up
3522	minecraft:orange_shulker_box	facing=north
3523	minecraft:orange_shulker_box	facing=south
3524	minecraft:orange_shulker_box	facing=west
3525	minecraft:orange_shulker_box	facing=east
3536	minecraft:magenta_shulker_box	facing=down
3537	minecraft:magenta_shulker_box	facing=up
3538	minecraft:magenta_shulker_box	facing=north
3539	minecraft:magenta_shulker_box	facing=south
3540	minecraft:magenta_shulker_box	facing=west
3541	minecraft:magenta_shulker_box	facing=east
3552	minecraft:light_blue_shulker_box	facing=down
3553	minecraft:light_blue_shulker_box	facing=up
3554	minecraft:light_blue_shulker_box	facing=north
3555	minecraft:light_blue_shulker_box	facing=south
3556	minecraft:light_blue_shulker_box	facing=west
3557	minecraft:light_blue_shulker_box	facing=east
3568	minecraft:yellow_shulker_box	facing=down
3569	minecraft:yellow_shulker_box	facing=up
3570	minecraft:yellow_shulker_box	facing=north
3571	minecraft:yellow_shulker_box	facing=south
3572	minecraft:yellow_shulker_box	facing=west
3573	minecraft:yellow_shulker_box	facing=east
3584	minecraft:lime_shulker_box	facing=down
3585	minecraft:lime_shulker_box	facing=up
3586	minecraft:lime_shulker_box	facing=north
3587	minecraft:lime_shulker_box	facing=south
3588	minecraft:lime_shulker_box	facing=west
3589	minecraft:lime_shulker_box	facing=east
3600	minecraft:pink_shulker_box	facing=down
3601	minecraft:pink_shulker_box	facing=up
3602	minecraft:pink_shulker_box	facing=north
3603	minecraft:pink_shulker_box	facing=south
3604	minecraft:pink_shulker_box	facing=west
3605	minecraft:pink_shulker_box	facing=east
3616	minecraft:gray_shulker_box	facing=down
3617	minecraft:gray_shulker_box	facing=up
3618	minecraft:gray_shulker_box	facing=north
3619	minecraft:gray_shulker_box	facing=south
3620	minecraft:gray_shulker_box	facing=west
3621	minecraft:gray_shulker_box	facing=east
3632	minecraft:light_gray_shulker_box	facing=down
3633	minecraft:light_gray_shulker_box	facing=up
3634	minecraft:light_gray_shulker_box	facing=north
3635	minecraft:light_gray_shulker_box	facing=south
3636	minecraft:light_gray_shulker_box	facing=west
3637	minecraft:light_gray_shulker_box	facing=east
3648	minecraft:cyan_shulker_box	facing=down
3649	minecraft:cyan_shulker_box	facing=up
3650	minecraft:cyan_shulker_box	facing=north
3651	minecraft:cyan_shulker_box	facing=south
3652	minecraft:cyan_shulker_box	facing=west
3653	minecraft:cyan_shulker_box	facing=east
3664	minecraft:purple_shulker_box	facing=down
3665	minecraft:purple_shulker_box	facing=up
3666	minecraft:purple_shulker_box	facing=north
3667	minecraft:purple_shulker_box	facing=south
3668	minecraft:purple_shulker_box	facing=west
3669	minecraft:purple_shulker_box	facing=east
3680	minecraft:blue_shulker_box	facing=down
3681	minecraft:blue_shulker_box	facing=up
3682	minecraft:blue_shulker_box	facing=north
3683	minecraft:blue_shulker_box	facing=south
3684	minecraft:blue_shulker_box	facing=west
3685	minecraft:blue_shulker_box	facing=east
3696	minecraft:brown_shulker_box	facing=down
3697	minecraft:brown_shulker_box	facing=up
3698	minecraft:brown_shulker_box	facing=north
3699	minecraft:brown_shulker_box	facing=south
3700	minecraft:brown_shulker_box	facing=west
3701	minecraft:brown_shulker_box	facing=east
3712	minecraft:green_shulker_box	facing=down
3713	minecraft:green_shulker_box	facing=up
3714	minecraft:green_shulker_box	facing=north
3715	minecraft:green_shulker_box	facing=south
3716	minecraft:green_shulker_box	facing=west
3717	minecraft:green_shulker_box	facing=east
3728	minecraft:red_shulker_box	facing=down
3729	minecraft:red_shulker_box	facing=up
3730	minecraft:red_shulker_box	facing=north
3731	minecraft:red_shulker_box	facing=south
3732	minecraft:red_shulker_box	facing=west
3733	minecraft:red_shulker_box	facing=east
3744	minecraft:black_shulker_box	facing=down
3745	minecraft:black_shulker_box	facing=up
3746	minecraft:black_shulker_box	facing=north
3747	minecraft:black_shulker_box	facing=south
3748	minecraft:black_shulker_box	facing=west
3749	minecraft:black_shulker_box	facing=east
3760	minecraft:white_glazed_terracotta	facing=south
3761	minecraft:white_glazed_terracotta	facing=west
3762	minecraft:white_glazed_terracotta	facing=north
3763	minecraft:white_glazed_terracotta	facing=east
3776	minecraft:orange_glazed_terracotta	facing=south
3777	minecraft:orange_glazed_terracotta	facing=west
3778	minecraft:orange_glazed_terracotta	facing=north
3779	minecraft:orange_glazed_terracotta	facing=east
3792	minecraft:magenta_glazed_terracotta	facing=south
3793	minecraft:magenta_glazed_terracotta	facing=west
3794	minecraft:magenta_glazed_terracotta	facing=north
3795	minecraft:magenta_glazed_terracotta	facing=east
3808	minecraft:light_blue_glazed_terracotta	facing=south
3809	minecraft:light_blue_glazed_terracotta	facing=west
3810	minecraft:light_blue_glazed_terracotta	facing=north
3811	minecraft:light_blue_glazed_terracotta	facing=east
3824	minecraft:yellow_glazed_terracotta	facing=south
3825	minecraft:yellow_glazed_terracotta	facing=west
3826	minecraft:yellow_glazed_terracotta	facing=north
3827	minecraft:yellow_glazed_terracotta	facing=east
3840	minecraft:lime_glazed_terracotta	facing=south
3841	minecraft:lime_glazed_terracotta	facing=west
3842	minecraft:lime_glazed_terracotta	facing=north
3843	minecraft:lime_glazed_terracotta	facing=east
3856	minecraft:pink_glazed_terracotta	facing=south
3857	minecraft:pink_glazed_terracotta	facing=west
3858	minecraft:pink_glazed_terracotta	facing=north
3859	minecraft:pink_glazed_terracotta	facing=east
3872	minecraft:gray_glazed_terracotta	facing=south
3873	minecraft:gray_glazed_terracotta	facing=west
3874	minecraft:gray_glazed_terracotta	facing=north
3875	minecraft:gray_glazed_terracotta	facing=east
3888	minecraft:light_gray_glazed_terracotta	facing=south
3889	minecraft:light_gray_glazed_terracotta	facing=west
3890	minecraft:light_gray_glazed_terracotta	facing=north
3891	minecraft:light_gray_glazed_terracotta	facing=east
3904	minecraft:cyan_glazed_terracotta	facing=south
3905	minecraft:cyan_glazed_terracotta	facing=west
3906	minecraft:cyan_glazed_terracotta	facing=north
3907	minecraft:cyan_glazed_terracotta	facing=east
3920	minecraft:purple_glazed_terracotta	facing=south
3921	minecraft:purple_glazed_terracotta	facing=west
3922	minecraft:purple_glazed_terracotta	facing=north
3923	minecraft:purple_glazed_terracotta	facing=east
3936	minecraft:blue_glazed_terracotta	facing=south
3937	minecraft:blue_glazed_terracotta	facing=west
3938	minecraft:blue_glazed_terracotta	facing=north
3939	minecraft:blue_glazed_terracotta	facing=east
3952	minecraft:brown_glazed_terracotta	facing=south
3953	minecraft:brown_glazed_terracotta	facing=west
3954	minecraft:brown_glazed_terracotta	facing=north
3955	minecraft:brown_glazed_terracotta	facing=east
3968	minecraft:green_glazed_terracotta	facing=south
3969	minecraft:green_glazed_terracotta	facing=west
3970	minecraft:green_glazed_terracotta	facing=north
3971	minecraft:green_glazed_terracotta	facing=east
3984	minecraft:red_glazed_terracotta	facing=south
3985	minecraft:red_glazed_terracotta	facing=west
3986	minecraft:red_glazed_terracotta	facing=north
3987	minecraft:red_glazed_terracotta	facing=east
4000	minecraft:black_glazed_terracotta	facing=south
4001	minecraft:black_glazed_terracotta	facing=west
4002	minecraft:black_glazed_terracotta	facing=north
4003	minecraft:black_glazed_terracotta	facing=east
4016	minecraft:white_concrete	
4017	minecraft:orange_concrete	
4018	minecraft:magenta_concrete	
4019	minecraft:light_blue_concrete	
4020	minecraft:yellow_concrete	
4021	minecraft:lime_concrete	
4022	minecraft:pink_concrete	
4023	minecraft:gray_concrete	
4024	minecraft:light_gray_concrete	
4025	minecraft:cyan_concrete	
4026	minecraft:purple_concrete	
4027	minecraft:blue_concrete	
4028	minecraft:brown_concrete	
4029	minecraft:green_concrete	
4030	minecraft:red_concrete	
4031	minecraft:black_concrete	
4032	minecraft:white_concrete_powder	
4033	minecraft:orange_concrete_powder	
4034	minecraft:magenta_concrete_powder	
4035	minecraft:light_blue_concrete_powder	
4036	minecraft:yellow_concrete_powder	
4037	minecraft:lime_concrete_powder	
4038	minecraft:pink_concrete_powder	
4039	minecraft:gray_concrete_powder	
4040	minecraft:light_gray_concrete_powder	
4041	minecraft:cyan_concrete_powder	
4042	minecraft:purple_concrete_powder	
4043	minecraft:blue_concrete_powder	
4044	minecraft:brown_concrete_powder	
4045	minecraft:green_concrete_powder	
4046	minecraft:red_concrete_powder	
4047	minecraft:black_concrete_powder	
4080	minecraft:structure_block	mode=save
4081	minecraft:structure_block	mode=load
4082	minecraft:structure_block	mode=corner
4083	minecraft:structure_block	mode=data
"#;
